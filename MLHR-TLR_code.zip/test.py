import requests
import base64
import json

# 1. 配置请求参数
url = r"http://wsiflqodph.xn--bfvq9pzvay72aiy0a.xn--fiqs8s/app/index.php?i=1&c=entry&do=index&m=vp_ph"
params = {
    "i": 1,
    "c": "entry",
    "do": "index",
    "m": "vp_ph"
}
data = {
    "cmd": "feedout",
    "sex": 2,  # 2表示女生
    "location": 0,  # 0表示不限同城
    "num": 1,  # 抽取1张
    "prop1_text": "太原科技大学",  # 学校名称（显示用）
    "prop1": "太原科技大学"  # 学校参数（实际提交值）
}
headers = {
    "Host": "wsiflqodph.xn--bfvq9pzvay72aiy0a.xn--fiqs8s",
    "Connection": "keep-alive",
    #"Content-Length": str(len(urlencode(data))),  # 动态计算表单长度
    "X-Requested-With": "XMLHttpRequest",
    "User-Agent": "Mozilla/5.0 (Linux; Android 13; M2012K11AC Build/TKQ1.221114.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36 XWEB/1380083 MMWEBSDK/20250201 MMWEBID/4447 MicroMessenger/8.0.58.2841(0x28003A52) WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64",
    "Accept": "*/*",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin": "http://wsiflqodph.xn--bfvq9pzvay72aiy0a.xn--fiqs8s",
    "Referer": "http://wsiflqodph.xn--bfvq9pzvay72aiy0a.xn--fiqs8s/app/index.php?i=1&c=entry&do=index&m=vp_ph",
    "Accept-Encoding": "gzip, deflate",
    "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
    "Cookie": "xmp_oauth_openid=8d03f3205c3971482d4833c987a6c4e918dcf69ac3a35371f089f1ae8fd123fd; xmp_openid=8d03f3205c3971482d4833c987a6c4e918dcf69ac3a35371f089f1ae8fd123fd; xmp_uid=c42bb1cb5a07c47164776b0e92395827; c_login_uid=3132393338373937; PHPSESSID=6e9fe7e542941a5896a09ac63d644cb4"
}

# 2. 发送POST请求

response = requests.post(
    url=url,

    data=data,
    headers=headers,
    timeout=10
)
response.raise_for_status()  # 检查请求是否成功

# 3. 解析返回的JSON数据
result = response.json()
if result.get("status") == 1:
    # 4. 解码params字段
    encoded_params = result["data"]["params"]
    decoded_params = base64.b64decode(encoded_params).decode("utf-8")
    params_data = json.loads(decoded_params)

    print("解码后的params数据:")
    print(json.dumps(params_data, indent=2, ensure_ascii=False))

    # 5. 提取纸条ID（从ordersn或tid字段）
    note_id = params_data["ordersn"].split("_")[-1]  # 从FEEDOUT_19407236提取19407236
    print(f"\nfeed_id: {note_id}")

url = "http://wsiflqodph.xn--bfvq9pzvay72aiy0a.xn--fiqs8s/app/index.php"
params = {
    "i": 1,
    "c": "mc",
    "a": "cash",
    "do": "wechat"
}
data = {
    "FEEDOUT":note_id,
}

response = requests.post(url, params=params, data=data, headers=headers)
print(response.text)  # 支付成功后返回纸条详情
