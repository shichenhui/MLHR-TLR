from collections import Counter

import scipy.io as scio
import numpy as np
import torch
from numpy import genfromtxt
from sklearn.preprocessing import normalize
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import scipy.io as scio
from sklearn.manifold import TSNE
from metrics import cal_clustering_metric,re_newpre
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE#进行降维
from sklearn.preprocessing import normalize
import os
import sys
import numpy as np
import torch as th
import torchvision
import torchvision.transforms as transforms
MNIST_TEST = 'mnist_test'
UMIST = 'UMIST'
COIL20 = 'COIL20'
JAFFE = 'JAFFE'
PALM = 'Palm'
USPS = 'USPSdata_20_uni'
SEGMENT = 'segment_uni'
NEWS = '20news_uni'
TEXT = 'text1_uni'
ISOLET = 'Isolet'
COIL20X = 'COIL20-3v'
orl = "ORL_mtv"
caltech = "Caltech-5V-7"
msrcv = "MSRCV1"
yale = "yaleA_3view"
sources = "3sources_gmc"
webkb = "WebKB"
leaves = "100leaves"
bbc="bbcsport"
scene = "scene-15"
def load_cora():
    path = 'data/cora.mat'
    data = scio.loadmat(path)
    labels = data['gnd']
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['fea']
    print(X)
    X = X.astype(np.float32)
    print(X.shape[1])
    X /= np.max(X)

    links = data['W']
    return X, labels, links

def Handwrite(txt_path):
    txt_path = 'data/mfeat/{}'.format(txt_path)	# txt文本路径
    f = open(txt_path)
    data_lists = f.readlines()	#读出的是str类型

    dataset= []
    # 对每一行作循环
    for data in data_lists:
        data1 = data.strip('\n')	# 去掉开头和结尾的换行符
        data2 = data1.split(' ')	# 把tab作为间隔符
        data2 = list(filter(lambda x:x!='',data2))
        dataset.append(list(map(float,data2)))	# 把这一行的结果作为元素加入列表dataset
    return np.array(dataset)
#sence
"""def load_data(name):
    listdata = {}
    path = '{}.mat'.format(name)
    #path = 'data/MSRCV1.mat'
    data = scio.loadmat(path)
    print(data)
    labels = data['Y']
    X = data['X']
    print(X.shape)
    for i in range(X.shape[1]):
        print(X[0][i].shape)
        listdata["{}".format(i)] = X[0][i]
       
    print(labels.reshape((labels.shape[0],)))
    return listdata, labels.reshape((labels.shape[0],))"""

"""def load_data(name):
    listdata1 = []
    path = '{}.mat'.format(name)
    # path = 'data/MSRCV1.mat'
    data = scio.loadmat(path)
    print(data)
    labels = data['gt']
    print(labels.shape)
    X = data['X']
    print(X[0][0].shape)
    print(X.shape)
    listlabel = np.zeros((labels.shape[1],1))


    for j in range(listlabel.shape[0]):
        listlabel[j,0] = labels[0][j]
    print((X.reshape((1,2))).shape)
    return  (X.reshape((1,2))).shape, listlabel"""

"""def load_data(name):
    listdata = {}
    path = '{}.mat'.format(name)
    # path = 'data/MSRCV1.mat'
    data = scio.loadmat(path)
    print(data)
    labels = data['truelabel']
    print(labels.shape)
    print(labels[0][1])
    X = data['data']
    print(X.shape)
    listlabel = np.zeros((labels[0][1][0].shape[0],))
    for i in range(X.shape[1]):
        print(X[0][i].shape)
        listdata["{}".format(i)] = X[0][i]
    for j in range(labels[0][1][0].shape[0]):
        listlabel[j] = labels[0][1][0][j]
    print(listlabel)
    return listdata, listlabel"""

#caltech
"""def load_data(name):
    listdata = {}

    path = 'data/{}.mat'.format(name)
    #path = 'data/Hdigit.mat'
    data = scio.loadmat(path)
    print(data)
    labels = data['Y']
    X = data['X']
    print(X.shape,labels.shape)
    listlabel= np.zeros((labels.shape[0],))
    print(X[3][0].shape)
    for i in range(X.shape[0]):
        re = np.zeros((X[i][0].shape[0],X[i][0].shape[1]))
        for t in range(X[i][0].shape[0]):
            re[t,:] = X[i][0][t,:]
        listdata["{}".format(i)] = re
    print(listdata["2"].shape)
    for j in range(labels.shape[0]):
        listlabel[j] = labels[j]
    print(listlabel)
    #print(listdata["0"].shape)
    #X = X.astype(np.float32)
    #print(listdata,labelxin.reshape((labelxin.shape[0],)).shape)
    #print(listdata.shape)
    return listdata, listlabel"""



"""def load_data(name):
    listdata = {}
    print(name)
    for i in range(len(name)):
        data = Handwrite(name[i])
        data_numpy = np.zeros((2000,data.shape[1]))
        for j in range(data.shape[0]):
            data_numpy[j]=data[j]
        #data_numpy = normalize(data_numpy)
        listdata[name[i]]=data_numpy
        print(listdata[name[i]].shape)

    Y_label = np.zeros((listdata[name[i]].shape[0],))
    for z in range(listdata[name[i]].shape[0]):
        Y_label[z] = z//200
    #listdata = np.array(listdata)
   # print(listdata,Y_label)
    print(Y_label)
    return listdata,Y_label"""

"""def Handwrite(txt_path):
    txt_path = 'data/mfeat/{}'.format(txt_path)	# txt文本路径
    f = open(txt_path)
    data_lists = f.readlines()	#读出的是str类型

    dataset= []
    # 对每一行作循环
    for data in data_lists:
        data1 = data.strip('\n')	# 去掉开头和结尾的换行符
        data2 = data1.split(' ')	# 把tab作为间隔符
        data2 = list(filter(lambda x:x!='',data2))
        dataset.append(list(map(float,data2)))	# 把这一行的结果作为元素加入列表dataset
    return np.array(dataset)


def load_data(name):
    listdata = {}

    for i in range(len(name)):
        data = Handwrite(name[i])
     #   print(Handwrite(name[i]).shape)
        data_numpy = np.zeros((1000,data.shape[1]))
        for j in range(data.shape[0]):
            if j%2==0:
                data_numpy[j//2]=data[j]
        listdata[name[i]]=data_numpy
    Y_label = np.zeros((listdata[name[i]].shape[0],))
    for z in range(listdata[name[i]].shape[0]):
        Y_label[z] = z//100
    #listdata = np.array(listdata)
   # print(listdata,Y_label)
    return listdata,Y_label"""

#mrsc
"""def load_data(name):
    listdata = {}
    path = 'data/{}.mat'.format(name)
    #path = 'data/MSRCV1.mat'
    data = scio.loadmat(path)
    print(data)
    labels = data['Y']
    X = data['X']
    print(X.shape)
    for i in range(X.shape[0]):
        #X[i][0]
        X[i][0] = X[i][0].astype(np.float32)
        X[i][0] = normalize(X[i][0])
        #X[i][0]/= np.max(X[i][0])
        print(X[i][0].shape)
        listdata["{}".format(i)] = X[i][0]

    return listdata, labels.reshape((labels.shape[0],))"""

#3SOURCES_GMC
"""def load_data(name):
    listdata = {}
    path = 'data/{}.mat'.format(name)
    data = scio.loadmat(path)
    print(data)

    labels = data['truelabel']
    print(data['data'].shape[1])
    print(labels[0][1].shape)
    listlabel = {}
    Y_label = np.zeros((int(labels[0][1].shape[1]), ))

    for i in range(data['data'].shape[1]):
        listdata["{}".format(i)] = data['data'][0][i]#X[0][i]
        print(listdata["{}".format(i)].shape)
        print((listdata["{}".format(i)]))
    print("jie")
    print(labels[0][1].shape)
    print(Y_label.shape)
    for j in range(labels[0][1].shape[1]):
        Y_label[j] = labels[0][1][0][j]

    return listdata, Y_label"""


#ORL
"""def load_data(name):
    listdata = {}
    path = 'data/{}.mat'.format(name)
    #path = 'data/ORL.mat'
    data = scio.loadmat(path)
    print(data)
    #print(data)
    labels = data['gt']
    print(labels)
    #print(labels)
    X = data['X']
    print(X[0][1].shape)
    for i in range(X.shape[1]):
        #X[i][0] /= np.max(X[i][0])
        #X[i][0] = normalize(X[i][0])
        listdata["{}".format(i)] = X[0][i].T
        print(listdata["{}".format(i)])
    #X = X.astype(np.float32)
    listlabel = np.zeros((labels.shape[0]))
    for j in range(labels.shape[0]):
        listlabel[j] = labels[j][0]
    print(listlabel)
    return listdata,listlabel"""

#WebKB
"""def load_data(name):
    listdata = {}
    path = 'data/{}.mat'.format(name)
    data = scio.loadmat(path)
    print(data)

    labels = data['gnd']
    # print(X.shape)
    print(labels.shape)
    listlabel = {}
    Y_label = np.zeros((int(labels.shape[0]),))
    print(data['X'].shape)
    for i in range(data['X'].shape[1]):
        listdata["{}".format(i)] = data['X'][0][i]  # .toarray()X[0][i]
        print(listdata["{}".format(i)].shape)

    for j in range(labels.shape[0]):
        Y_label[j] = labels[j][0]
    print(Y_label)
    return listdata, Y_label"""

#bbcsport
"""def load_data(name):
    listdata = {}
    path = 'data/{}.mat'.format(name)
    data = scio.loadmat(path)
    print(data)

    labels = data['Y']
    #print(X.shape)
    print(labels.shape)
    listlabel = {}
    Y_label = np.zeros((int(labels.shape[0]), ))

    for i in range(data['X'].shape[1]):
        listdata["{}".format(i)] = data['X'][0][i].toarray()#X[0][i]
        print(listdata["{}".format(i)].shape)
        print((listdata["{}".format(i)]))

    print(labels.shape[1])
    print(Y_label.shape)
    for j in range(labels.shape[0]):
        Y_label[j] = labels[j][0]

    return listdata, Y_label"""

#COIL
"""def load_data(name):
    path = 'data/{}.mat'.format(name)
    data = scio.loadmat(path)
    print(data)
    # print(data.shape)
    labels = data['Y']
    print(type(labels))
    labels = np.reshape(labels, (labels.shape[0],))
    X = data['X']
    # print(X.shape)
    print(X[0][2].shape)
    label_np = np.zeros(labels.shape[0], )

    data_np = {}
    for j in range(X.shape[1]):
        data_np["{}".format(j)] = X[0][j]
        print(data_np["{}".format(j)].shape)
    for g in range(label_np.shape[0]):
        label_np[g] = labels[g]
    print(label_np)

    return data_np, label_np"""

def load_data(name):
    listdata = {}
    path = '{}.mat'.format(name)
    #path = 'data/MSRCV1.mat'
    data = scio.loadmat(path)
    print(data)
    labels = data['Y'].flatten()
    X = data['X']
    print(X.shape)
    if name in ['MSRCV1', 'mfeat'] :
        X = X.T
    for i in range(X.shape[1]):
        print(X[0][i].shape)
        listdata["{}".format(i)] = X[0][i]

    print(Counter(labels))
    return listdata, labels.reshape((labels.shape[0],))

"""def load_data(name):
    listdata = {}
    path = 'data/{}.mat'.format(name)
    data = scio.loadmat(path)
    print(data)

    labels = data['gnd']
    # print(X.shape)
    print(labels.shape)
    listlabel = {}
    Y_label = np.zeros((int(labels.shape[0]),))
    print(data['X'].shape)
    for i in range(data['X'].shape[1]):
        listdata["{}".format(i)] = data['X'][0][i]  # .toarray()X[0][i]
        print(listdata["{}".format(i)].shape)

    for j in range(labels.shape[0]):
        Y_label[j] = labels[j][0]
    print(Y_label)
    return listdata, Y_label"""

def load_guanpudata():
    path = 'data/star_AFGK_2kx4.csv'
    my_data = genfromtxt(path, delimiter=',')
    data = normalize(my_data)
    pca = PCA(n_components=100)  # 降到100维
    data = pca.fit_transform(data)  # 用pca模型来训练,并降到100维
    data_sub = []
    lable = [0,1,2,3]
    n = int(my_data.shape[0]/len(lable))
    lablelist = [i for i in range(int(data.shape[0]/10))]
    for i in range(len(lable)):
        for j in range(int(n/10)):
            data_sub.append(data[i*n+j*10])
            lablelist[int(n/10)*i+j]= lable[i]
    lablelist = np.array(lablelist)
    data_sub = np.array(data_sub)
    km = KMeans(n_clusters=len(lable)).fit(data_sub)
    prediction = km.predict(data_sub)
    pred_index = re_newpre(lablelist, prediction)
    acc, nmi = cal_clustering_metric(lablelist, prediction)
    tsne = TSNE(n_components=2, random_state=0)  # 将文件将为二维
    result = tsne.fit_transform(data_sub)
    color = ['cornflowerblue', 'gold', "gray", "violet"]
    for i in range(len(prediction)):
        if pred_index[i] == 1:
            plt.scatter(result[i, 0], result[i, 1], s=0.7, c=color[lablelist[i]])
        else:
            plt.scatter(result[i, 0], result[i, 1], s=0.7, c='red')
    plt.xlabel("x")
    plt.ylabel("y")
    # plt.legend((A, F, G, K, incorrect), ("A", "F", "G", "K","False"))  # 图片标签
    plt.title('k-means --- ACC: %5.4f, NMI: %5.4f' % (acc, nmi))
    plt.show()
    return data_sub,lablelist
"""def load_data(name):
    listdata = {}
    path = 'data/{}.mat'.format(name)
    #path = 'data/MSRCV1.mat'
    data = scio.loadmat(path)
    print(data)
    labels = data['data']
    X = data['truelabel']
    print(X.shape)
    for i in range(X.shape[1]):
        print(X[0][i].shape)
        X[i][0] = X[i][0].astype(np.float32)
        X[i][0] = normalize(X[i][0])
        #X[i][0]/= np.max(X[i][0])
        #print(X[i][0].shape)
        listdata["{}".format(i)] = X[i][0]

    return listdata, labels.reshape((labels.shape[0],))"""

if __name__ == '__main__':
    #dataset = ["mfeat-fac", "mfeat-fou", "mfeat-kar", "mfeat-mor", "mfeat-pix", "mfeat-zer"]
    load_data("bbcsport_TLR")#bbcsportdata
    #print(load_guanpudata())
    #data,lablelist = load_guanpudata()
    #print(data.shape,lablelist.shape)
    #coil()