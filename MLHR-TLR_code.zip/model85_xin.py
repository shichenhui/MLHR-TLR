#-*- codeing = utf-8 -*-
#@Time : 2023/7/10 15:34
#@Author :辛永杰
#@File : model85_xin.py
#@Sofeware : PyCharm
import evaluation
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
import utils6
import math
import torch.fft as fft
from metrics import cal_clustering_metric, re_newpre


"""class Deep_Network(torch.nn.Module):
    def __init__(self, set, data, labels, layers=None,lam = None, num_neighbors=3, learning_rate=10 ** -3,
                 max_iter=50, max_epoch = None, update=True, num_clusteres=3, links=0, device=None,W=None,lamb1=None):
        super(Deep_Network, self).__init__()
        if layers is None:
            layers = [1024, 256, 64]
        if device is None:
            device = torch.device('cuda: 0' if torch.cuda.is_available() else 'cpu')
        self.set = set
        self.data = data
        self.labels = labels
        self.W=W
        self.lamb1 = lamb1
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.num_clusteres = num_clusteres
        self.max_epoch = max_epoch
        self.num_neighbors = num_neighbors + 1
        self.embedding_dim = {}  # layers[-1]
        self.mid_dim = {}  # layers[1]
        self.input_dim = {}  # layers[0]
        for t in self.set:
            self.embedding_dim[t] = layers[t][-1]
            self.mid_dim[t] = layers[t][1]
            self.input_dim[t] = layers[t][0]
        self.update = update
        self.lam = lam
        self.max_neighbors = self.cal_max_neighbors()
        self.links = links
        self.device = device
        self.iter_id = 0
        self.embedding = None
        self._build_up()
        self.dimension = 5
        self.shuzhi = 0

    def creatnet(self,in_dim,out_dim,n):
        linear = torch.nn.Linear(out_dim,in_dim)
        linear.weight = torch.nn.Parameter(torch.rand(out_dim,in_dim))
        linear.bias = torch.nn.Parameter(torch.rand(n,out_dim))
        return linear

    def _build_up(self):
        self.linear1 = self.creatnet(self.data[self.set[0]].shape[1], self.mid_dim[self.set[0]],self.data[self.set[0]].shape[0])
        self.relu1 = torch.nn.ReLU(inplace=True)
        self.linear7 = self.creatnet(self.mid_dim[self.set[0]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig1 = torch.nn.Softmax(dim=1)

        self.linear2 = self.creatnet(self.data[self.set[1]].shape[1], self.mid_dim[self.set[1]],self.data[self.set[0]].shape[0])
        self.relu2 = torch.nn.ReLU(inplace=True)
        self.linear8 = self.creatnet(self.mid_dim[self.set[1]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig2 = torch.nn.Softmax(dim=1)

        self.linear3 = self.creatnet(self.data[self.set[2]].shape[1], self.mid_dim[self.set[2]],self.data[self.set[0]].shape[0])
        self.relu3 = torch.nn.ReLU(inplace=True)
        self.linear9 = self.creatnet(self.mid_dim[self.set[2]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig3 = torch.nn.Softmax(dim=1)


    def cal_max_neighbors(self):
        if not self.update:
            return 0

        size = self.data[self.set[0]].shape[0]
        self.num_clusters = np.unique(self.labels).shape[0]

        return 1.0 * size / self.num_clusters

    def forward(self):
        self.diwei1 = {}
        self.diwei = {}
        h1 = self.linear1(self.data[self.set[0]])
        h2 = self.relu1(h1)
        self.diwei[self.set[0]] = self.linear7(h2)
        #self.diwei[self.set[0]].matmul()
        #self.diwei1[self.set[0]] = self.sig1(h3)

        h4 = self.linear2(self.data[self.set[1]])
        h5 = self.relu2(h4)
        self.diwei[self.set[1]] = self.linear8(h5)
        #self.diwei1[self.set[1]] = self.sig2(h6)

        h7 = self.linear3(self.data[self.set[2]])
        h8 = self.relu3(h7)
        self.diwei[self.set[2]]= self.linear9(h8)
        #self.diwei1[self.set[2]] = self.sig3(h9)



    # 进行更改图
    def update_graph(self):
        weights = adagae1.utils6.cal_weights_via_CAN_updata(self.S, self.num_neighbors, self.num_clusteres)
        weights = weights.detach()
        # raw_weights[h] = raw_weights[h].detach()

        # Laplacian = adagae1.utils6.get_Laplacian_from_weights(weights)
        return weights

    def max_perform(self, perform_list):
        max_acc = []
        for j in range(len(perform_list)):
            max_acc.append(perform_list[j]['result']['accuracy'])
        acc_max_id = max_acc.index(max(max_acc))
        print("最终结果{}".format(perform_list[acc_max_id]['result']))


    def build_loss(self, HH, lam1,HH1):  # , weights
        size = self.num_clusters
        loss = 0
        loss1 = 0
        loss2 = 0
        loss3 = 0
        self.v = {}
        self.zonghe = 0
        self.indices = {}
        self.fenshu = {}



        self.yusuan = {}

        for r in range(len(self.set)):
            self.diwei1[self.set[r]] = HH1[r].cuda().matmul(self.diwei[self.set[r]].cuda())
            loss1 += lam1 * (self.diwei1[self.set[r]].cuda().t().matmul(HH[r].cuda().matmul(self.diwei1[self.set[r]].cuda()))).sum() / self.diwei1[self.set[r]].shape[1] # self.embedding
        loss = loss + loss1
        self.new_distance = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        # 求相似矩阵
        self.yuanwai = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.yuannei = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.Z = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        self.H_H = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.num_clusters])
        I = torch.eye(self.data[self.set[0]].shape[0])
        for d in range(len(self.set)):

            self.new_distance[d, :, :] = self.dianji(self.diwei1[self.set[d]].cuda())  # +torch.ge(distance[d, :, :].cuda(), Pingju.cuda())
            DW = self.jianju(self.diwei1[self.set[d]].cuda())
            H_H = self.jianju(self.H[d,:,:].cuda())
            #DW1 = ((torch.diag_embed(1/DW.sum(dim=1).sqrt())).matmul(DW)).matmul((torch.diag_embed(1/DW.sum(dim=1).sqrt())))
            #H_H1 = ((torch.diag_embed(1 / H_H.sum(dim=1).sqrt())).matmul(H_H)).matmul((torch.diag_embed(1 / H_H.sum(dim=1).sqrt())))
            #H_H*torch.log(H_H/(DW+1e-10))
            loss2 += (H_H*torch.log(H_H/(DW+1e-10))).sum(dim=1).sum()/self.diwei1[self.set[d]].shape[0]
            #loss2 += torch.trace((self.H[d,:,:].cuda().t().matmul(I.cuda()-(DW1.cuda()+H_H1.cuda())/2)).matmul(self.H[d,:,:].cuda())).sum() / self.diwei1[self.set[d]].shape[0]


        loss = loss + loss2 #+loss3
        self.weights_xin = torch.zeros([len(self.set) * (len(self.set) - 1), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.weights = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])


        return loss,loss1,loss2

    def Consistent(self):
        self.Ada_weights_z = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        self.z_xin = torch.zeros([self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]]).cuda()
        for y in range(len(self.set)):
            self.z_xin += torch.exp(self.new_distance[y, :, :].cuda())

        self.Ada_weights = {}
        for z in range(len(self.set)):
            self.Ada_weights[z] = torch.div(torch.exp(self.new_distance[z, :, :].cuda()), self.z_xin.cuda())

        # self.S得到最终的共识图
        self.Ada_weights_xin = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        for n in range(len(self.set)):
            self.Ada_weights_xin += self.Ada_weights[n]
            self.Ada_weights_z += torch.mul(self.Ada_weights[n], self.new_distance[n, :, :].cuda())
        self.S = torch.div(self.Ada_weights_z, self.Ada_weights_xin)

    def dianji(self,diwei_feature):
        sigmoid = torch.nn.Sigmoid()
        return sigmoid(diwei_feature.matmul(diwei_feature.t()))

    def jianju(self,diwei_feature):
        softmax = torch.nn.Softmax()
        return softmax(-adagae1.utils6.distance(diwei_feature.t(),diwei_feature.t()))#+torch.eye(diwei_feature.shape[0]).cuda()

    def lam1(self,AA):
        #AA = adagae1.utils6.distance(Yy.cuda().detach().t(), Yy.cuda().detach().t())
        DD = torch.diag_embed(AA.sum(dim=1))
        DD1 = torch.diag_embed(1/AA.sum(dim=1).sqrt())
        lam = (DD1.matmul(torch.subtract(DD,AA))).matmul(DD1)
        return lam

    def Lapacian(self,L,num):
        e, v = torch.symeig(L, eigenvectors=True)
        sorted, indices = torch.sort(e, descending=False)
        return v[:,indices[:num]]

    def run(self):

        acclist = []
        nmilist = []
        torch.cuda.empty_cache()
        print(self.parameters())
        optimizer = torch.optim.Adam(self.parameters(), lr=self.learning_rate)
        self.to(self.device)

        self.new_distance_Begin = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_L = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_LK1 = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_LK2 = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        HH = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.H = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.num_clusters])
        HH1 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        self.Y1 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.Y2 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.Y3 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.Y4 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        for g in range(len(self.set)):
            HH1[g,:,:] = self.dianji(self.data[self.set[g]])
        for k in range(HH1.shape[1]):
            u, s, v = torch.svd(fft.fft(HH1[:, k, :].cpu().detach()))
            s_xin1 = torch.ge(s - 0.1*self.W, 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] -  0.1 * self.W[i]
            self.new_distance_LK1[:, k, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

        for k1 in range(HH1.shape[0]):
            u, s, v = torch.svd(fft.fft(HH1[k1, :, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

            s_xin1 = torch.ge(s - torch.ones([HH1.shape[1], ]), 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] - 1
            self.new_distance_LK2[k1, :, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

        for y1 in range(len(self.set)):
            AA1 = self.lam1(self.new_distance_LK1[y1, :, :].cuda().detach()*self.lamb1 + self.new_distance_LK2[y1, :,:].cuda().detach()*(1-self.lamb1))
            self.H[y1, :, :] = self.Lapacian(AA1.cuda(),self.num_clusters)
            HH[y1, :, :] = self.lam1(self.dianji(self.H[y1, :, :].cuda())+ torch.eye(self.H[y1, :, :].shape[0]).cuda())
            AA = self.dianji(self.H[y1, :, :].cuda())+ torch.eye(self.H[y1, :, :].shape[0]).cuda()
            DD = torch.diag_embed(1 / AA.sum(dim=1).sqrt())
            HH1[y1, :, :] = (DD.matmul(AA)).matmul(DD)
            self.new_distance_Begin = self.dianji(self.H[y1, :, :].cuda())


        for lam1 in self.lam:

            print("----lam={}----".format(lam1))
            for i in range(self.max_iter):
                print(i)
                optimizer.zero_grad()
                self()
                loss, loss1,loss2= self.build_loss(HH, lam1, HH1)#,loss3
                loss.backward()
                optimizer.step()

                print(loss, loss1,loss2)#,loss3

            for e in range(self.new_distance.shape[0]):

                self.new_distance_LK1[e,:,:]  = (self.new_distance[e,:,:].cuda() + self.dianji(self.H[e,:,:].cuda())+self.new_distance_L[e,:,:].cuda()+(self.Y1[e,:,:].cuda()+self.Y2[e,:,:].cuda())/lam1)/2
                self.new_distance_LK2[e, :, :]  = (self.new_distance[e, :,:].cuda() + self.dianji(self.H[e, :, :].cuda()) + self.new_distance_L[e,:,:].cuda() + ( self.Y3[e,:,:].cuda() + self.Y4[e,:,:].cuda()) / lam1) / 2
            for k in range(self.new_distance.shape[1]):
                u, s, v = torch.svd(fft.fft(self.new_distance_LK1[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                s_xin1 = torch.ge(s - 0.1*self.W, 0)
                for i in range(s_xin1.shape[0]):
                    if s_xin1[i] == False:
                        s[i] = 0
                    else:
                        s[i] = s[i] - 0.1*self.W[i]
                self.new_distance_LK1[:, k, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

            for k1 in range(self.new_distance.shape[0]):
                u, s, v = torch.svd(fft.fft(self.new_distance_LK2[k1, :, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                s_xin1 = torch.ge(s -torch.ones([self.new_distance.shape[1], ]), 0)
                for i in range(s_xin1.shape[0]):
                    if s_xin1[i] == False:
                        s[i] = 0
                    else:
                        s[i] = s[i] - 1
                self.new_distance_LK2[k1, :, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

            for y1 in range(len(self.set)):
                self.new_distance_L[y1, :, :] =  (self.new_distance_LK1[y1, :, :].cuda().detach()+ self.new_distance_LK2[y1, :,:].cuda().detach())/2-(self.Y2[y1,:,:].cuda()+self.Y4[y1,:,:].cuda())/lam1


            for g in range(len(self.set)):
                self.H[g, :, :] = self.Lapacian(self.lam1(self.new_distance_L[g, :, :].cuda().detach()), self.num_clusters)


                AA = self.dianji(self.new_distance[g, :, :].cuda()).cuda().detach() + torch.eye(self.new_distance[g, :, :].shape[0]).cuda()
                DD = torch.diag_embed(1 / AA.sum(dim=1).sqrt())
                HH1[g, :, :] = (DD.matmul(AA)).matmul(DD)
                HH[g, :, :] = self.lam1(AA.cuda())
                self.Y1[g, :, :] = self.new_distance[e,:,:].cuda() + self.dianji(self.H[e,:,:].cuda()) - self.new_distance_LK1[g,:,:].cuda()
                self.Y2[g, :, :] = self.new_distance_L[g, :, :].cuda() - self.new_distance_LK1[g,:,:].cuda()
                self.Y3[g, :, :] = self.new_distance[e,:,:].cuda() + self.dianji(self.H[e,:,:].cuda()) - self.new_distance_LK2[g,:,:].cuda()
                self.Y4[g, :, :] = self.new_distance_L[g, :, :].cuda() - self.new_distance_LK2[g,:,:].cuda()
                #self.new_distance_Begin[g, :, :] = self.dianji(self.H[g, :, :].cuda())
                self.new_distance[g, :, :] = self.dianji(self.H[g, :, :].cuda())
            self.Consistent()
            acc, nmi = self.clustering(SC=True)
            acclist.append(acc)
            nmilist.append(nmi)

            colors = list(mcolors.CSS4_COLORS.keys())
            # acc_max_id = acclist.index(max(acclist))
            prediction_max = self.prediction  # self.predictionlist[acc_max_id]
            print(AMLG.evaluation.clustering(prediction_max.astype(np.int), self.labels))
            predictiondata_max = self.indicator  # self.predictiondata[acc_max_id]

            tsne = TSNE(n_components=2, random_state=0)  # 将文件将为二维
            result = tsne.fit_transform(predictiondata_max)  # [xin_index,:]
            listdata = [t for t in range(np.unique(self.labels).shape[0])]
            font1 = {'family': 'Times New Roman',
                     'weight': 'normal',
                     'size': 16,
                     }
            for i in listdata:
                plt.scatter(result[np.sort(prediction_max) == i, 0], result[np.sort(prediction_max) == i, 1],
                            s=6,
                            c=colors[int(i) + 10])  # ,label = "%d"%i
            # plt.scatter(result[pred_index==0, 0], result[pred_index==0, 1], s=6, c=colors[self.num_clusters+15],label = "error")
            plt.xlabel("x", fontsize=16)
            plt.ylabel("y", fontsize=16)
            plt.xticks(fontsize=16)
            plt.yticks(fontsize=16)

            plt.title("The t-SNE visualization of MSRC-v1 dataset", fontsize=16)

            plt.show()


        colors = list(mcolors.CSS4_COLORS.keys())
        # acc_max_id = acclist.index(max(acclist))
        prediction_max = self.prediction  # self.predictionlist[acc_max_id]
        #print(AMLG.evaluation.clustering(prediction_max.astype(np.int), self.labels))
        predictiondata_max = self.indicator  # self.predictiondata[acc_max_id]

        tsne = TSNE(n_components=2, random_state=0)  # 将文件将为二维
        result = tsne.fit_transform(predictiondata_max)  # [xin_index,:]
        listdata = [t for t in range(np.unique(self.labels).shape[0])]
        font1 = {'family': 'Times New Roman',
                 'weight': 'normal',
                 'size': 16,
                 }
        for i in listdata:
            plt.scatter(result[np.sort(prediction_max) == i, 0], result[np.sort(prediction_max) == i, 1], s=6,c=colors[int(i) + 10])  # ,label = "%d"%i
        # plt.scatter(result[pred_index==0, 0], result[pred_index==0, 1], s=6, c=colors[self.num_clusters+15],label = "error")
        plt.xlabel("x", fontsize=16)
        plt.ylabel("y", fontsize=16)
        plt.xticks(fontsize=16)
        plt.yticks(fontsize=16)

        plt.title("The t-SNE visualization of MSRC-v1 dataset", fontsize=16)

        plt.show()

        return acclist, nmilist

    def Yy_PCA(self, Yy):
        Y = {}
        for g in range(len(self.set)):
            s_sum = 0
            s_sum1 = 0
            YY = torch.matmul(Yy[self.set[g]].cuda().t(), Yy[self.set[g]].cuda())
            e, v = torch.symeig(YY, eigenvectors=True)
            s, indices = torch.sort(e, descending=True)
            for t in range(len(s)):
                s_sum = s_sum + s[t]
            for d in range(len(s)):
                s_sum1 = s_sum1 + s[d]
                if (s_sum1 / s_sum) > self.threshold:
                    #print("jie")
                    Y[self.set[g]] = Yy[self.set[g]].matmul(v[:, indices[:d+1]])
                    break

        return Y
    def clustering(self, SC=True):
        n_clusters = np.unique(self.labels).shape[0]
        if SC:
            degree = torch.sum(self.S, dim=1).pow(-0.5)
            L = (self.S * degree).t() * degree
            L = L.cpu()
            _, vectors = L.symeig(True)
            indicator = vectors[:, -n_clusters:]
            indicator = indicator / (indicator.norm(dim=1) + 10 ** -10).repeat(n_clusters, 1).t()
            self.indicator = indicator.detach().numpy()
            km = KMeans(n_clusters=n_clusters).fit(self.indicator)
            self.prediction = km.predict(self.indicator)

            # print(self.labels.shape, prediction.shape)
            acc, nmi = cal_clustering_metric(self.labels, self.prediction)
            print('SC --- ACC: %5.4f, NMI: %5.4f' % (acc, nmi), end='')
        print('')
        return acc, nmi"""
"""class Deep_Network(torch.nn.Module):
    def __init__(self, set, data, labels, layers=None,lam = None, num_neighbors=3, learning_rate=10 ** -3,
                 max_iter=50, max_epoch = None, update=True, num_clusteres=3, links=0, device=None,threshold=None):
        super(Deep_Network, self).__init__()
        if layers is None:
            layers = [1024, 256, 64]
        if device is None:
            device = torch.device('cuda: 0' if torch.cuda.is_available() else 'cpu')
        self.set = set
        self.data = data
        self.labels = labels
        self.threshold=threshold
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.num_clusteres = num_clusteres
        self.max_epoch = max_epoch
        self.num_neighbors = num_neighbors + 1
        self.embedding_dim = {}  # layers[-1]
        self.mid_dim = {}  # layers[1]
        self.input_dim = {}  # layers[0]
        for t in self.set:
            self.embedding_dim[t] = layers[t][-1]
            self.mid_dim[t] = layers[t][1]
            self.input_dim[t] = layers[t][0]
        self.update = update
        self.lam = lam
        self.max_neighbors = self.cal_max_neighbors()
        self.links = links
        self.device = device
        self.iter_id = 0
        self.embedding = None
        self._build_up()
        self.dimension = 5
        self.shuzhi = 0

    def creatnet(self,in_dim,out_dim,n):
        linear = torch.nn.Linear(out_dim,in_dim)
        linear.weight = torch.nn.Parameter(torch.rand(out_dim,in_dim))
        linear.bias = torch.nn.Parameter(torch.rand(n,out_dim))
        return linear
    def createw(self):
        weight = torch.zeros([len(self.set),self.num_clusteres, self.num_clusters])
        bias = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.num_clusters])
        for t in range(len(self.set)):
            weight[t,:,:] = torch.rand(self.num_clusteres, self.num_clusters)
            bias[t,:,:] = torch.rand(self.data[self.set[t]].shape[0], self.num_clusters)
        return torch.nn.Parameter(weight, requires_grad=True),torch.nn.Parameter(bias, requires_grad=True)

    def _build_up(self):
        self.weight ,self.bias = self.createw()
        self.linear1 = self.creatnet(self.data[self.set[0]].shape[1], self.mid_dim[self.set[0]],self.data[self.set[0]].shape[0])
        self.relu1 = torch.nn.ReLU(inplace=True)
        self.linear7 = self.creatnet(self.mid_dim[self.set[0]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig1 = torch.nn.Softmax(dim=1)
        self.linearW7 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

        self.linear2 = self.creatnet(self.data[self.set[1]].shape[1], self.mid_dim[self.set[1]],self.data[self.set[0]].shape[0])
        self.relu2 = torch.nn.ReLU(inplace=True)
        self.linear8 = self.creatnet(self.mid_dim[self.set[1]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig2 = torch.nn.Softmax(dim=1)
        self.linearW8 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

        self.linear3 = self.creatnet(self.data[self.set[2]].shape[1], self.mid_dim[self.set[2]],self.data[self.set[0]].shape[0])
        self.relu3 = torch.nn.ReLU(inplace=True)
        self.linear9 = self.creatnet(self.mid_dim[self.set[2]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig3 = torch.nn.Softmax(dim=1)
        self.linearW9 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

       
    def cal_max_neighbors(self):
        if not self.update:
            return 0

        size = self.data[self.set[0]].shape[0]
        self.num_clusters = np.unique(self.labels).shape[0]

        return 1.0 * size / self.num_clusters

    def forward(self):
        self.diwei1 = {}
        self.diwei = {}
        h1 = self.linear1(self.data[self.set[0]])
        h2 = self.relu1(h1)
        self.diwei[self.set[0]] = self.linear7(h2)
        #self.diwei[self.set[0]].matmul()
        #self.diwei1[self.set[0]] = self.sig1(h3)

        h4 = self.linear2(self.data[self.set[1]])
        h5 = self.relu2(h4)
        self.diwei[self.set[1]] = self.linear8(h5)
        #self.diwei1[self.set[1]] = self.sig2(h6)

        h7 = self.linear3(self.data[self.set[2]])
        h8 = self.relu3(h7)
        self.diwei[self.set[2]]= self.linear9(h8)
        #self.diwei1[self.set[2]] = self.sig3(h9)


    # 进行更改图
    def update_graph(self):
        weights = adagae1.utils6.cal_weights_via_CAN_updata(self.S, self.num_neighbors, self.num_clusteres)
        weights = weights.detach()
        # raw_weights[h] = raw_weights[h].detach()

        # Laplacian = adagae1.utils6.get_Laplacian_from_weights(weights)
        return weights

    def max_perform(self, perform_list):
        max_acc = []
        for j in range(len(perform_list)):
            max_acc.append(perform_list[j]['result']['accuracy'])
        acc_max_id = max_acc.index(max(max_acc))
        print("最终结果{}".format(perform_list[acc_max_id]['result']))


    def build_loss(self, HH, lam1, HH1, Ada):  # , weights
        size = self.num_clusters
        loss = 0
        loss1 = 0
        loss2 = 0
        loss3 = 0
        self.v = {}
        self.zonghe = 0
        self.indices = {}
        self.fenshu = {}



        self.yusuan = {}

        for r in range(len(self.set)):
            self.diwei1[self.set[r]] = HH1[r].cuda().matmul(self.diwei[self.set[r]].cuda())
            loss1 += lam1 * (self.diwei1[self.set[r]].cuda().t().matmul(HH[r].cuda().matmul(self.diwei1[self.set[r]].cuda()))).sum() / self.diwei1[self.set[r]].shape[1] # self.embedding
        loss = loss + loss1
        self.new_distance = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        # 求相似矩阵
        self.yuanwai = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.yuannei = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.Z = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        self.H_H = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.num_clusters])
        for d in range(len(self.set)):

            self.new_distance[d, :, :] = self.dianji(self.diwei1[self.set[d]].cuda())  # +torch.ge(distance[d, :, :].cuda(), Pingju.cuda())
            DW = self.jianju(self.diwei1[self.set[d]].cuda())
            #H_H = self.Ada_neighbor(self.H[d,:,:].cuda(),num_neighbors)

            #H_H*torch.log(H_H/(DW+1e-10))
            loss2 += (Ada[d,:,:].cuda()*torch.log(Ada[d,:,:].cuda()/(DW.cuda()+1e-10))).sum(dim=1).sum()/(self.diwei1[self.set[d]].shape[0] *self.diwei1[self.set[d]].shape[0])
            
        loss = loss + loss2 #+loss3
        self.weights_xin = torch.zeros([len(self.set) * (len(self.set) - 1), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.weights = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])


        return loss,loss1,loss2#,loss3

    def Consistent(self):
        self.Ada_weights_z = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        self.z_xin = torch.zeros([self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]]).cuda()
        for y in range(len(self.set)):
            self.z_xin += torch.exp(self.new_distance[y, :, :].cuda())

        self.Ada_weights = {}
        for z in range(len(self.set)):
            self.Ada_weights[z] = torch.div(torch.exp(self.new_distance[z, :, :].cuda()), self.z_xin.cuda())

        # self.S得到最终的共识图
        self.Ada_weights_xin = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        for n in range(len(self.set)):
            self.Ada_weights_xin += self.Ada_weights[n]
            self.Ada_weights_z += torch.mul(self.Ada_weights[n], self.new_distance[n, :, :].cuda())
        self.S = torch.div(self.Ada_weights_z, self.Ada_weights_xin)


    def dianji(self,diwei_feature):
        sigmoid = torch.nn.Sigmoid()
        return sigmoid(diwei_feature.matmul(diwei_feature.t()))

    def jianju(self,diwei_feature):
        softmax = torch.nn.Softmax()
        return softmax(-adagae1.utils6.distance(diwei_feature.t(),diwei_feature.t()))

    def Ada_neighbor(self, diwei_feature, num_neighbors):
        size = diwei_feature.shape[0]
        distances = adagae1.utils6.distance(diwei_feature.t(), diwei_feature.t())
        sorted_distances, _ = distances.sort(dim=1)
        top_k = sorted_distances[:, num_neighbors]
        top_k = torch.t(top_k.repeat(size, 1)) + 10**-10
        ada_distances = torch.ge(top_k,distances)
        ada_distances_exp = torch.exp(-distances)*(ada_distances)
        return ada_distances_exp*(1/torch.t(ada_distances_exp.sum(dim=1).repeat(size, 1)))
    def Ada_neighbor(self, diwei_feature, num_neighbors):
        size = diwei_feature.shape[0]
        #distances = adagae1.utils6.distance(diwei_feature.t(), diwei_feature.t())
        distances = diwei_feature.matmul(diwei_feature.t())
        sorted_distances, _ = distances.sort(dim=1,descending=True)
        top_k = sorted_distances[:, num_neighbors]
        top_k = torch.t(top_k.repeat(size, 1)) + 10**-10
        ada_distances = torch.ge(distances,top_k)
        ada_distances_exp = 1/(1+torch.exp(distances))*(ada_distances)
        return ada_distances_exp
    def lam1(self,AA):
        #AA = adagae1.utils6.distance(Yy.cuda().detach().t(), Yy.cuda().detach().t())
        DD = torch.diag_embed(AA.sum(dim=1))
        DD1 = torch.diag_embed(1/AA.sum(dim=1).sqrt())
        lam = (DD1.matmul(torch.subtract(DD,AA))).matmul(DD1)
        return lam

    def Lapacian(self,L,num):
        e, v = torch.symeig(L, eigenvectors=True)
        sorted, indices = torch.sort(e, descending=False)
        return v[:,indices[:num]]

    def run(self):

        acclist = []
        nmilist = []
        torch.cuda.empty_cache()
        print(self.parameters())
        optimizer = torch.optim.Adam(self.parameters(), lr=self.learning_rate)
        self.to(self.device)

        self.new_distance_Begin = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        HH = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.H = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.num_clusters])
        HH1 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_font = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_with = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        Ada = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        for g in range(len(self.set)):
            HH1[g,:,:] = self.dianji(self.data[self.set[g]])
        for k in range(HH1.shape[1]):
            u, s, v = torch.svd(fft.fft(HH1[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

            s_xin1 = torch.ge(s - torch.ones([len(self.set), ]), 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] - 1
            self.new_distance_font[:, k, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))


        for y1 in range(len(self.set)):
            AA1 = self.lam1(self.new_distance_font[y1, :, :].cuda().detach())#*0.5 + self.new_distance_with[y1, :,:].cuda().detach()*0.5
            self.H[y1, :, :] = self.Lapacian(AA1.cuda(),self.num_clusters)


        for lam1 in self.lam:
            print("----lam={}----".format(lam1))
            num_neighbors = self.num_neighbors
            for epoch in range(self.max_epoch):
                for y1 in range(len(self.set)):
                    Ada[y1, :, :] =  self.Ada_neighbor(self.H[y1, :, :].cuda(),num_neighbors)
                    HH[y1, :, :] = self.lam1(Ada[y1, :, :])
                    DD = torch.diag_embed(1 / Ada[y1, :, :].sum(dim=1).sqrt())
                    HH1[y1, :, :] = (DD.matmul(Ada[y1, :, :])).matmul(DD)

                for i in range(self.max_iter):
                    print(i)
                    optimizer.zero_grad()
                    self()
                    loss, loss1,loss2= self.build_loss(HH, lam1, HH1, Ada)
                    loss.backward()
                    optimizer.step()
                    print(loss, loss1,loss2)
                for k in range(self.new_distance.shape[1]):
                    u, s, v = torch.svd(fft.fft(self.new_distance[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                    s_xin1 = torch.ge(s - torch.ones([len(self.set), ]), 0)
                    for i in range(s_xin1.shape[0]):
                        if s_xin1[i] == False:
                            s[i] = 0
                        else:
                            s[i] = s[i] - 1
                    self.new_distance_font[:, k, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                            v.t()))


                for y1 in range(len(self.set)):
                    self.new_distance[y1, :, :] = self.new_distance_font[y1, :, :].cuda().detach()#*0.5 + self.new_distance_with[y1, :,:].cuda().detach()*0.5

                for g in range(len(self.set)):
                    self.H[g, :, :] = self.Lapacian((self.lam1(
                            self.dianji(self.H[g, :, :].cuda())) * 0.9+ self.lam1(
                            self.new_distance[g, :, :].cuda().detach()) * 0.1), self.num_clusters)

                if num_neighbors < self.max_neighbors:
                    num_neighbors = num_neighbors + 5
                    for g in range(len(self.set)):
                        Ada[g, :, :] = self.Ada_neighbor(self.H[g, :, :].cuda(),num_neighbors)
                        AA = Ada[g, :, :].cuda() + torch.eye(
                                self.new_distance_font[g, :, :].shape[0]).cuda()
                        DD = torch.diag_embed(1 / AA.sum(dim=1).sqrt())
                        HH1[g, :, :] = (DD.matmul(AA)).matmul(DD)

                        HH[g, :, :] = self.lam1(Ada[g, :, :].cuda())

                else:
                    break

                self.Consistent()
                acc, nmi = self.clustering(SC=True)
                acclist.append(acc)
                nmilist.append(nmi)

                colors = list(mcolors.CSS4_COLORS.keys())
                # acc_max_id = acclist.index(max(acclist))
                prediction_max = self.prediction  # self.predictionlist[acc_max_id]
                print(AMLG.evaluation.clustering(prediction_max.astype(np.int), self.labels))
                predictiondata_max = self.indicator  # self.predictiondata[acc_max_id]

                tsne = TSNE(n_components=2, random_state=0)  # 将文件将为二维
                result = tsne.fit_transform(predictiondata_max)  # [xin_index,:]
                listdata = [t for t in range(np.unique(self.labels).shape[0])]
                font1 = {'family': 'Times New Roman',
                         'weight': 'normal',
                         'size': 16,
                         }
                for i in listdata:
                    plt.scatter(result[np.sort(prediction_max) == i, 0], result[np.sort(prediction_max) == i, 1],
                                s=6,
                                c=colors[int(i) + 10])  # ,label = "%d"%i
                # plt.scatter(result[pred_index==0, 0], result[pred_index==0, 1], s=6, c=colors[self.num_clusters+15],label = "error")
                plt.xlabel("x", fontsize=16)
                plt.ylabel("y", fontsize=16)
                plt.xticks(fontsize=16)
                plt.yticks(fontsize=16)

                plt.title("The t-SNE visualization of MSRC-v1 dataset", fontsize=16)

                plt.show()


        return acclist, nmilist

    def Yy_PCA(self, Yy):
        Y = {}
        for g in range(len(self.set)):
            s_sum = 0
            s_sum1 = 0
            YY = torch.matmul(Yy[self.set[g]].cuda().t(), Yy[self.set[g]].cuda())
            e, v = torch.symeig(YY, eigenvectors=True)
            s, indices = torch.sort(e, descending=True)
            for t in range(len(s)):
                s_sum = s_sum + s[t]
            for d in range(len(s)):
                s_sum1 = s_sum1 + s[d]
                if (s_sum1 / s_sum) > self.threshold:
                    #print("jie")
                    Y[self.set[g]] = Yy[self.set[g]].matmul(v[:, indices[:d+1]])
                    break

        return Y
    def clustering(self, SC=True):
        n_clusters = np.unique(self.labels).shape[0]
        if SC:
            degree = torch.sum(self.S, dim=1).pow(-0.5)
            L = (self.S * degree).t() * degree
            L = L.cpu()
            _, vectors = L.symeig(True)
            indicator = vectors[:, -n_clusters:]
            indicator = indicator / (indicator.norm(dim=1) + 10 ** -10).repeat(n_clusters, 1).t()
            self.indicator = indicator.detach().numpy()
            km = KMeans(n_clusters=n_clusters).fit(self.indicator)
            self.prediction = km.predict(self.indicator)
            # print(self.labels.shape, prediction.shape)
            acc, nmi = cal_clustering_metric(self.labels, self.prediction)
            print('SC --- ACC: %5.4f, NMI: %5.4f' % (acc, nmi), end='')
        print('')
        return acc, nmi"""
"""class Deep_Network(torch.nn.Module):
    def __init__(self, set, data, labels, layers=None,lam = None, num_neighbors=3, learning_rate=10 ** -3,
                 max_iter=50, max_epoch = None, update=True, num_clusteres=3, links=0, device=None,W=None,lamb1=None):
        super(Deep_Network, self).__init__()
        if layers is None:
            layers = [1024, 256, 64]
        if device is None:
            device = torch.device('cuda: 0' if torch.cuda.is_available() else 'cpu')
        self.set = set
        self.data = data
        self.labels = labels
        self.W=W
        self.lamb1 = lamb1
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.num_clusteres = num_clusteres
        self.max_epoch = max_epoch
        self.num_neighbors = num_neighbors + 1
        self.embedding_dim = {}  # layers[-1]
        self.mid_dim = {}  # layers[1]
        self.input_dim = {}  # layers[0]
        for t in self.set:
            self.embedding_dim[t] = layers[t][-1]
            self.mid_dim[t] = layers[t][1]
            self.input_dim[t] = layers[t][0]
        self.update = update
        self.lam = lam
        self.max_neighbors = self.cal_max_neighbors()
        self.links = links
        self.device = device
        self.iter_id = 0
        self.embedding = None
        self._build_up()
        self.dimension = 5
        self.shuzhi = 0

    def creatnet(self,in_dim,out_dim,n):
        linear = torch.nn.Linear(out_dim,in_dim)
        linear.weight = torch.nn.Parameter(torch.rand(out_dim,in_dim))
        linear.bias = torch.nn.Parameter(torch.rand(n,out_dim))
        return linear

    def _build_up(self):
        self.linear1 = self.creatnet(self.data[self.set[0]].shape[1], self.mid_dim[self.set[0]],self.data[self.set[0]].shape[0])
        self.relu1 = torch.nn.ReLU(inplace=True)
        self.linear7 = self.creatnet(self.mid_dim[self.set[0]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig1 = torch.nn.Softmax(dim=1)

        self.linear2 = self.creatnet(self.data[self.set[1]].shape[1], self.mid_dim[self.set[1]],self.data[self.set[0]].shape[0])
        self.relu2 = torch.nn.ReLU(inplace=True)
        self.linear8 = self.creatnet(self.mid_dim[self.set[1]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig2 = torch.nn.Softmax(dim=1)

        self.linear3 = self.creatnet(self.data[self.set[2]].shape[1], self.mid_dim[self.set[2]],self.data[self.set[0]].shape[0])
        self.relu3 = torch.nn.ReLU(inplace=True)
        self.linear9 = self.creatnet(self.mid_dim[self.set[2]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig3 = torch.nn.Softmax(dim=1)



    def cal_max_neighbors(self):
        if not self.update:
            return 0

        size = self.data[self.set[0]].shape[0]
        self.num_clusters = np.unique(self.labels).shape[0]

        return 1.0 * size / self.num_clusters

    def forward(self):
        self.diwei1 = {}
        self.diwei = {}
        h1 = self.linear1(self.data[self.set[0]])
        h2 = self.relu1(h1)
        self.diwei[self.set[0]] = self.linear7(h2)
        #self.diwei[self.set[0]].matmul()
        #self.diwei1[self.set[0]] = self.sig1(h3)

        h4 = self.linear2(self.data[self.set[1]])
        h5 = self.relu2(h4)
        self.diwei[self.set[1]] = self.linear8(h5)
        #self.diwei1[self.set[1]] = self.sig2(h6)

        h7 = self.linear3(self.data[self.set[2]])
        h8 = self.relu3(h7)
        self.diwei[self.set[2]]= self.linear9(h8)
        #self.diwei1[self.set[2]] = self.sig3(h9)



    # 进行更改图
    def update_graph(self):
        weights = adagae1.utils6.cal_weights_via_CAN_updata(self.S, self.num_neighbors, self.num_clusteres)
        weights = weights.detach()
        # raw_weights[h] = raw_weights[h].detach()

        # Laplacian = adagae1.utils6.get_Laplacian_from_weights(weights)
        return weights

    def max_perform(self, perform_list):
        max_acc = []
        for j in range(len(perform_list)):
            max_acc.append(perform_list[j]['result']['accuracy'])
        acc_max_id = max_acc.index(max(max_acc))
        print("最终结果{}".format(perform_list[acc_max_id]['result']))


    def build_loss(self, HH, lam1,HH1,num_neighbor):  # , weights
        size = self.num_clusters
        loss = 0
        loss1 = 0
        loss2 = 0
        loss3 = 0
        self.v = {}
        self.zonghe = 0
        self.indices = {}
        self.fenshu = {}



        self.yusuan = {}

        for r in range(len(self.set)):
            self.diwei1[self.set[r]] = HH1[r].cuda().matmul(self.diwei[self.set[r]].cuda())
            loss1 += lam1 * (self.diwei1[self.set[r]].cuda().t().matmul(HH[r].cuda().matmul(self.diwei1[self.set[r]].cuda()))).sum() / self.diwei1[self.set[r]].shape[1] # self.embedding
        loss = loss + loss1
        self.new_distance = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        # 求相似矩阵
        self.yuanwai = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.yuannei = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.Z = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        self.H_H = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.num_clusters])
        I = torch.eye(self.data[self.set[0]].shape[0])
        for d in range(len(self.set)):
            self.new_distance[d, :, :] = self.dianji_neightbor(self.diwei1[self.set[d]].cuda(),num_neighbor)  # +torch.ge(distance[d, :, :].cuda(), Pingju.cuda())
            DW = self.jianju(self.diwei1[self.set[d]].cuda())
            H_H = self.jianju(self.H[d,:,:].cuda())

            loss2 += (H_H*torch.log(H_H/(DW+1e-10))).sum(dim=1).sum()/self.diwei1[self.set[d]].shape[0]
            #loss2 += torch.trace((self.H[d,:,:].cuda().t().matmul(I.cuda()-(DW1.cuda()+H_H1.cuda())/2)).matmul(self.H[d,:,:].cuda())).sum() / self.diwei1[self.set[d]].shape[0]


        loss = loss + loss2 #+loss3
        self.weights_xin = torch.zeros([len(self.set) * (len(self.set) - 1), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.weights = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])


        return loss,loss1,loss2#,loss3

    def Consistent(self):
        self.Ada_weights_z = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        self.z_xin = torch.zeros([self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]]).cuda()
        for y in range(len(self.set)):
            self.z_xin += torch.exp(self.new_distance[y, :, :].cuda())

        self.Ada_weights = {}
        for z in range(len(self.set)):
            self.Ada_weights[z] = torch.div(torch.exp(self.new_distance[z, :, :].cuda()), self.z_xin.cuda())

        # self.S得到最终的共识图
        self.Ada_weights_xin = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        for n in range(len(self.set)):
            self.Ada_weights_xin += self.Ada_weights[n]
            self.Ada_weights_z += torch.mul(self.Ada_weights[n], self.new_distance[n, :, :].cuda())
        self.S = torch.div(self.Ada_weights_z, self.Ada_weights_xin)

    def dianji(self,diwei_feature):
        sigmoid = torch.nn.Sigmoid()
        return sigmoid(diwei_feature.matmul(diwei_feature.t()))

    def dianji_neightbor(self, diwei_feature,num):
        sigmoid = torch.nn.Sigmoid()
        DW = sigmoid(diwei_feature.matmul(diwei_feature.t()))
        sorted_distances, _ = DW.sort(dim=1)
        top_k = sorted_distances[:, num]
        top_k1 = torch.ge(DW,torch.t(top_k.repeat(DW.shape[0], 1)) + 10 ** -10) * DW

        return top_k1

    def jianju(self,diwei_feature):
        softmax = torch.nn.Softmax()
        return softmax(-adagae1.utils6.distance(diwei_feature.t(),diwei_feature.t()))#+torch.eye(diwei_feature.shape[0]).cuda()

    def lam1(self,AA):
        #AA = adagae1.utils6.distance(Yy.cuda().detach().t(), Yy.cuda().detach().t())
        DD = torch.diag_embed(AA.sum(dim=1))
        DD1 = torch.diag_embed(1/AA.sum(dim=1).sqrt())
        lam = (DD1.matmul(torch.subtract(DD,AA))).matmul(DD1)
        return lam

    def Lapacian(self,L,num):
        e, v = torch.symeig(L, eigenvectors=True)
        sorted, indices = torch.sort(e, descending=False)
        return v[:,indices[:num]]

    def run(self):

        acclist = []
        nmilist = []
        torch.cuda.empty_cache()
        print(self.parameters())
        optimizer = torch.optim.Adam(self.parameters(), lr=self.learning_rate)
        self.to(self.device)

        self.new_distance_Begin = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        HH = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.H = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.num_clusters])
        HH1 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_font = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_with = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        for g in range(len(self.set)):
            HH1[g,:,:] = self.dianji_neightbor(self.data[self.set[g]],self.num_neighbors)
        for k in range(HH1.shape[1]):
            u, s, v = torch.svd(fft.fft(HH1[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

            s_xin1 = torch.ge(s - 0.1*self.W, 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] -  0.1 * self.W[i]
            self.new_distance_font[:, k, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

        for k1 in range(HH1.shape[0]):
            u, s, v = torch.svd(fft.fft(HH1[k1, :, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

            s_xin1 = torch.ge(s - torch.ones([HH1.shape[1], ]), 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] - 1
            self.new_distance_with[k1, :, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

        for y1 in range(len(self.set)):
            AA1 = self.lam1(self.new_distance_font[y1, :, :].cuda().detach()*self.lamb1 + self.new_distance_with[y1, :,:].cuda().detach()*(1-self.lamb1))
            self.H[y1, :, :] = self.Lapacian(AA1.cuda(),self.num_clusters)
            HH[y1, :, :] = self.lam1(self.dianji(self.H[y1, :, :].cuda())+ torch.eye(self.new_distance_font[g, :, :].shape[0]).cuda())
            AA = self.dianji(self.H[y1, :, :].cuda())+ torch.eye(self.new_distance_font[g, :, :].shape[0]).cuda()
            DD = torch.diag_embed(1 / AA.sum(dim=1).sqrt())
            HH1[y1, :, :] = (DD.matmul(AA)).matmul(DD)

        for e in range(self.new_distance_Begin.shape[0]):
            self.new_distance_Begin[e,:,:] = self.dianji(self.H[e, :, :].cuda())#self.new_distance_font[e, :, :].cuda().detach()*self.lamb1 + self.new_distance_with[e, :,:].cuda().detach()*(1-self.lamb1)

        for lam1 in self.lam:
            print("----lam={}----".format(lam1))
            num_neighbor = self.num_neighbors + 5
            for epoch in range(self.max_epoch):

                for i in range(self.max_iter):
                    print(i)
                    optimizer.zero_grad()
                    self()
                    loss, loss1,loss2= self.build_loss(HH, lam1, HH1,num_neighbor)
                    loss.backward()
                    optimizer.step()

                    print(loss, loss1,loss2)#,loss3

                #self.new_distance_Begin = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

                for e in range(self.new_distance.shape[0]):
                    self.new_distance_Begin[e,:,:] = (self.new_distance[e,:,:].cuda() + self.new_distance_Begin[e,:,:].cuda())/2

                for k in range(self.new_distance.shape[1]):
                    u, s, v = torch.svd(fft.fft(self.new_distance_Begin[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                    s_xin1 = torch.ge(s - 0.1*self.W, 0)
                    for i in range(s_xin1.shape[0]):
                        if s_xin1[i] == False:
                            s[i] = 0
                        else:
                            s[i] = s[i] - 0.1*self.W[i]
                    self.new_distance_font[:, k, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                            v.t()))

                for k1 in range(self.new_distance.shape[0]):
                    u, s, v = torch.svd(fft.fft(self.new_distance_Begin[k1, :, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                    s_xin1 = torch.ge(s -torch.ones([self.new_distance.shape[1], ]), 0)
                    for i in range(s_xin1.shape[0]):
                        if s_xin1[i] == False:
                            s[i] = 0
                        else:
                            s[i] = s[i] - 1
                    self.new_distance_with[k1, :, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                            v.t()))

                for y1 in range(len(self.set)):
                    self.new_distance[y1, :, :] = self.new_distance_font[y1, :, :].cuda().detach()*self.lamb1+ self.new_distance_with[y1, :,:].cuda().detach()*(1-self.lamb1)
                if num_neighbor < self.max_neighbors:
                    for g in range(len(self.set)):
                        self.H[g, :, :] = self.Lapacian((self.lam1(self.new_distance[g, :, :].cuda().detach())),self.num_clusters)
                        AA = self.dianji(self.H[g, :, :].cuda()).detach() + torch.eye(self.new_distance_font[g, :, :].shape[0]).cuda()
                        DD = torch.diag_embed(1 / AA.sum(dim=1).sqrt())
                        HH1[g, :, :] = (DD.matmul(AA)).matmul(DD)
                        HH[g, :, :] = self.lam1(AA.cuda())

                        self.new_distance[g, :, :] = self.dianji(self.H[g, :, :].cuda())

                    self.Consistent()
                    acc, nmi = self.clustering(SC=True)
                    acclist.append(acc)
                    nmilist.append(nmi)

                    num_neighbor = num_neighbor + 5

                else:
                    break




                colors = list(mcolors.CSS4_COLORS.keys())
                # acc_max_id = acclist.index(max(acclist))
                prediction_max = self.prediction  # self.predictionlist[acc_max_id]
                print(AMLG.evaluation.clustering(prediction_max.astype(np.int), self.labels))
                predictiondata_max = self.indicator  # self.predictiondata[acc_max_id]

                tsne = TSNE(n_components=2, random_state=0)  # 将文件将为二维
                result = tsne.fit_transform(predictiondata_max)  # [xin_index,:]
                listdata = [t for t in range(np.unique(self.labels).shape[0])]
                font1 = {'family': 'Times New Roman',
                         'weight': 'normal',
                         'size': 16,
                         }
                for i in listdata:
                    plt.scatter(result[np.sort(prediction_max) == i, 0], result[np.sort(prediction_max) == i, 1],
                                s=6,
                                c=colors[int(i) + 10])  # ,label = "%d"%i
                # plt.scatter(result[pred_index==0, 0], result[pred_index==0, 1], s=6, c=colors[self.num_clusters+15],label = "error")
                plt.xlabel("x", fontsize=16)
                plt.ylabel("y", fontsize=16)
                plt.xticks(fontsize=16)
                plt.yticks(fontsize=16)

                plt.title("The t-SNE visualization of COIL-20 dataset", fontsize=16)

                plt.show()




        return acclist, nmilist

    def Yy_PCA(self, Yy):
        Y = {}
        for g in range(len(self.set)):
            s_sum = 0
            s_sum1 = 0
            YY = torch.matmul(Yy[self.set[g]].cuda().t(), Yy[self.set[g]].cuda())
            e, v = torch.symeig(YY, eigenvectors=True)
            s, indices = torch.sort(e, descending=True)
            for t in range(len(s)):
                s_sum = s_sum + s[t]
            for d in range(len(s)):
                s_sum1 = s_sum1 + s[d]
                if (s_sum1 / s_sum) > self.threshold:
                    #print("jie")
                    Y[self.set[g]] = Yy[self.set[g]].matmul(v[:, indices[:d+1]])
                    break

        return Y
    def clustering(self, SC=True):
        n_clusters = np.unique(self.labels).shape[0]
        if SC:
            degree = torch.sum(self.S, dim=1).pow(-0.5)
            L = (self.S * degree).t() * degree
            L = L.cpu()
            _, vectors = L.symeig(True)
            indicator = vectors[:, -n_clusters:]
            indicator = indicator / (indicator.norm(dim=1) + 10 ** -10).repeat(n_clusters, 1).t()
            self.indicator = indicator.detach().numpy()
            km = KMeans(n_clusters=n_clusters).fit(self.indicator)
            self.prediction = km.predict(self.indicator)

            # print(self.labels.shape, prediction.shape)
            acc, nmi = cal_clustering_metric(self.labels, self.prediction)
            print('SC --- ACC: %5.4f, NMI: %5.4f' % (acc, nmi), end='')
        print('')
        return acc, nmi"""

class Deep_Network(torch.nn.Module):
    def __init__(self, set, data, labels, layers=None,lam = None,  learning_rate=10 ** -3,
                 max_iter=50, max_epoch = None, update=True, num_clusteres=3, links=0, device=None,W=None,lamb1=None,lamb1s = None , threshold = None, quanzhong=None):
        super(Deep_Network, self).__init__()
        if layers is None:
            layers = [1024, 256, 64]
        if device is None:
            device = torch.device('cuda: 0' if torch.cuda.is_available() else 'cpu')
        self.set = set
        self.data = data
        self.labels = labels
        self.W=W
        self.lamb1s = lamb1s
        self.threshold = threshold
        self.quanzhong =quanzhong
        self.lamb1 = lamb1
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.num_clusteres = num_clusteres
        self.max_epoch = max_epoch
        self.embedding_dim = {}  # layers[-1]
        self.mid_dim = {}  # layers[1]
        self.input_dim = {}  # layers[0]
        for t in self.set:
            self.embedding_dim[t] = layers[t][-1]
            self.mid_dim[t] = layers[t][1]
            self.input_dim[t] = layers[t][0]
        self.update = update
        self.lam = lam
        self.max_neighbors = self.cal_max_neighbors()
        self.links = links
        self.device = device
        self.iter_id = 0
        self.embedding = None
        self._build_up()
        self.dimension = 5
        self.shuzhi = 0

    def creatnet(self,in_dim,out_dim,n):
        linear = torch.nn.Linear(out_dim,in_dim)
        linear.weight = torch.nn.Parameter(torch.rand(out_dim,in_dim))
        linear.bias = torch.nn.Parameter(torch.rand(n,out_dim))
        return linear

    def _build_up(self):
        self.linear1 = self.creatnet(self.data[self.set[0]].shape[1], self.mid_dim[self.set[0]],self.data[self.set[0]].shape[0])
        self.relu1 = torch.nn.ReLU(inplace=True)
        self.linear7 = self.creatnet(self.mid_dim[self.set[0]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.relu1_1 = torch.nn.ReLU(inplace=True)
        #self.sig1 = torch.nn.Softmax(dim=1)

        self.linear2 = self.creatnet(self.data[self.set[1]].shape[1], self.mid_dim[self.set[1]],self.data[self.set[0]].shape[0])
        self.relu2 = torch.nn.ReLU(inplace=True)
        self.linear8 = self.creatnet(self.mid_dim[self.set[1]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.relu2_2 = torch.nn.ReLU(inplace=True)
        #self.sig2 = torch.nn.Softmax(dim=1)

        self.linear3 = self.creatnet(self.data[self.set[2]].shape[1], self.mid_dim[self.set[2]],self.data[self.set[0]].shape[0])
        self.relu3 = torch.nn.ReLU(inplace=True)
        self.linear9 = self.creatnet(self.mid_dim[self.set[2]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.relu3_3 = torch.nn.ReLU(inplace=True)
        #self.sig3 = torch.nn.Softmax(dim=1)

        self.linear4 = self.creatnet(self.data[self.set[3]].shape[1], self.mid_dim[self.set[3]],self.data[self.set[0]].shape[0])
        self.relu4 = torch.nn.ReLU(inplace=True)
        self.linear10 = self.creatnet(self.mid_dim[self.set[3]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.relu4_4 = torch.nn.ReLU(inplace=True)
        #self.sig4 = torch.nn.Softmax(dim=1)

        self.linear5 = self.creatnet(self.data[self.set[4]].shape[1], self.mid_dim[self.set[4]],self.data[self.set[0]].shape[0])
        self.relu5 = torch.nn.ReLU(inplace=True)
        self.linear11 = self.creatnet(self.mid_dim[self.set[4]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.relu5_5 = torch.nn.ReLU(inplace=True)
        #self.sig5 = torch.nn.Softmax(dim=1)

        '''self.linear6 = self.creatnet(self.data[self.set[5]].shape[1], self.mid_dim[self.set[5]],self.data[self.set[0]].shape[0])
        self.relu6 = torch.nn.ReLU(inplace=True)
        self.linear12 = self.creatnet(self.mid_dim[self.set[5]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.relu6_6 = torch.nn.ReLU(inplace=True)'''


        #self.sig6 = torch.nn.Softmax(dim=1)

    def cal_max_neighbors(self):
        if not self.update:
            return 0

        size = self.data[self.set[0]].shape[0]
        self.num_clusters = np.unique(self.labels).shape[0]

        return 1.0 * size / self.num_clusters

    def forward(self,HH1):
        self.diwei1 = {}
        self.diwei = {}
        h1 = self.linear1(self.data[self.set[0]])
        h2 = self.relu1(HH1[0].cuda().matmul(h1))
        self.diwei[self.set[0]] = self.linear7(h2)
        #self.diwei[self.set[0]].matmul()self.relu1_1()
        #self.diwei1[self.set[0]] = self.sig1(h3)

        h4 = self.linear2(self.data[self.set[1]])
        h5 = self.relu2(HH1[1].cuda().matmul(h4))
        self.diwei[self.set[1]] = self.linear8(h5)
        #self.diwei1[self.set[1]] = self.sig2(h6)self.relu2_2()

        h7 = self.linear3(self.data[self.set[2]])
        h8 = self.relu3(HH1[2].cuda().matmul(h7))
        self.diwei[self.set[2]]= self.linear9(h8)
        #self.diwei1[self.set[2]] = self.sig3(h9)self.relu3_3()

        h11 = self.linear4(self.data[self.set[3]])
        h12 = self.relu4(HH1[3].cuda().matmul(h11))
        self.diwei[self.set[3]]= self.linear10(h12)
        #self.diwei1[self.set[3]] = self.sig4(h13)self.relu4_4()

        h14 = self.linear5(self.data[self.set[4]])
        h15 = self.relu5(HH1[4].cuda().matmul(h14))
        #self.diwei[self.set[5]] = self.linear12(h18)
        self.diwei[self.set[4]]= self.linear11(h15)
        #self.diwei1[self.set[4]] = self.sig5(h16)self.relu5_5()

        '''h17 = self.linear6(self.data[self.set[5]])
        h18 = self.relu6(HH1[5].cuda().matmul(h17))
        self.diwei[self.set[5]] = self.linear12(h18)'''
        #self.diwei[self.set[5]]= self.relu6_6(self.linear12(h18))
        #self.diwei1[self.set[5]] = self.sig6(h19)

    # 进行更改图
    def update_graph(self):
        weights = utils6.cal_weights_via_CAN_updata(self.S, self.num_neighbors, self.num_clusteres)
        weights = weights.detach()
        # raw_weights[h] = raw_weights[h].detach()

        # Laplacian = adagae1.utils6.get_Laplacian_from_weights(weights)
        return weights

    def max_perform(self, perform_list):
        max_acc = []
        for j in range(len(perform_list)):
            max_acc.append(perform_list[j]['result']['accuracy'])
        acc_max_id = max_acc.index(max(max_acc))
        print("最终结果{}".format(perform_list[acc_max_id]['result']))


    def build_loss(self, HH, lam1,HH1):  # , weights
        size = self.num_clusters
        loss = 0
        loss1 = 0
        loss2 = 0
        loss3 = 0
        self.v = {}
        self.zonghe = 0
        self.indices = {}
        self.fenshu = {}



        self.yusuan = {}

        for r in range(len(self.set)):
            #print(HH1[r].shape,self.diwei[self.set[r]].shape)
            self.diwei1[self.set[r]] = HH1[r].cuda().matmul(self.diwei[self.set[r]].cuda())
            loss1 += lam1 * torch.diag(self.diwei1[self.set[r]].cuda().t().matmul(HH[r].cuda().matmul(self.diwei1[self.set[r]].cuda()))).sum() / self.diwei1[self.set[r]].shape[1] # self.embedding
            #loss1 += (self.diwei1[self.set[r]].cuda().t().matmul(HH[r].cuda().matmul(self.diwei1[self.set[r]].cuda()))).sum() / self.diwei1[self.set[r]].shape[1]
        self.new_distance = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        # 求相似矩阵
        self.yuanwai = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.yuannei = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.Z = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        self.H_H = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.num_clusters])
        I = torch.eye(self.data[self.set[0]].shape[0])
        for d in range(len(self.set)):

            #self.new_distance[d, :, :] = self.dianji(self.diwei1[self.set[d]].cuda())  # +torch.ge(distance[d, :, :].cuda(), Pingju.cuda())
            DW = self.jianju(self.diwei1[self.set[d]].cuda())
            H_H = self.jianju(self.H[d,:,:].cuda())
            #DW1 = ((torch.diag_embed(1/DW.sum(dim=1).sqrt())).matmul(DW)).matmul((torch.diag_embed(1/DW.sum(dim=1).sqrt())))
            #H_H1 = ((torch.diag_embed(1 / H_H.sum(dim=1).sqrt())).matmul(H_H)).matmul((torch.diag_embed(1 / H_H.sum(dim=1).sqrt())))
            #H_H*torch.log(H_H/(DW+1e-10))
            loss2 += (H_H.cuda()*torch.log(H_H.cuda()/(DW.cuda()+1e-10))).sum(dim=1).sum()/self.diwei1[self.set[d]].shape[0]

            #loss2 += torch.trace((self.H[d,:,:].cuda().t().matmul(I.cuda()-(DW1.cuda()+H_H1.cuda())/2)).matmul(self.H[d,:,:].cuda())).sum() / self.diwei1[self.set[d]].shape[0]


        loss = loss1 + loss2 #+loss3
        self.weights_xin = torch.zeros([len(self.set) * (len(self.set) - 1), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.weights = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])


        return loss,loss1,loss2#,loss3

    def Consistent(self):
        self.Ada_weights_z = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        self.z_xin = torch.zeros([self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]]).cuda()
        for y in range(len(self.set)):
            self.z_xin += torch.exp(self.new_distance[y, :, :].cuda())

        self.Ada_weights = {}
        for z in range(len(self.set)):
            self.Ada_weights[z] = torch.div(torch.exp(self.new_distance[z, :, :].cuda()), self.z_xin.cuda())

        # self.S得到最终的共识图
        self.Ada_weights_xin = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        for n in range(len(self.set)):
            self.Ada_weights_xin =self.Ada_weights_xin.cuda() +  self.Ada_weights[n].cuda()
            self.Ada_weights_z += torch.mul(self.Ada_weights[n].cuda(), self.new_distance[n, :, :].cuda())
        self.S = torch.div(self.Ada_weights_z.cuda(), self.Ada_weights_xin.cuda())

    def dianji(self,diwei_feature):
        sigmoid = torch.nn.Sigmoid()
        return sigmoid(diwei_feature.cuda().matmul(diwei_feature.cuda().t()))

    def PCA_fenjie(self,diwei_feature):
        sigmoid = torch.nn.Sigmoid()
        """Average_feature = torch.sum(diwei_feature,dim=0)/diwei_feature.shape[0]
        pca_feature = torch.subtract(diwei_feature,Average_feature.repeat(diwei_feature.shape[0],1))"""
        DW = diwei_feature.t().cuda().matmul(diwei_feature.cuda())
        #e, v = torch.symeig(DW, eigenvectors=True)
        e, v = torch.linalg.eigh(DW)
        s, indices = torch.sort(e, descending=True)
        s_sum = 0
        s_sum1 = 0
        i=0
        for t in range(len(s)):
            s_sum = s_sum + s[t]
        for d in range(len(s)):
            i = i +1
            s_sum1 = s_sum1 + s[d]
            if (s_sum1 / s_sum) > self.threshold:
                Y = diwei_feature.matmul(v[:, indices[:d + 1]])

                break
        print("xin")
        print(i)
        return sigmoid(Y.cuda().matmul(Y.cuda().t())),i

    def jianju(self,diwei_feature):
        softmax = torch.nn.Softmax()
        return softmax(-utils6.distance(diwei_feature.cuda().t(),diwei_feature.cuda().t()))#+torch.eye(diwei_feature.shape[0]).cuda()

    def lam1(self,AA):
        #AA = adagae1.utils6.distance(Yy.cuda().detach().t(), Yy.cuda().detach().t())
        DD = torch.diag_embed(AA.cuda().sum(dim=1))
        DD1 = torch.diag_embed(1/AA.cuda().sum(dim=1).sqrt())
        lam = (DD1.cuda().matmul(torch.subtract(DD.cuda(),AA.cuda()))).matmul(DD1.cuda())
        return lam

    def Lapacian(self,L,num):
        e, v = torch.linalg.eigh(L)
        #e, v = torch.symeig(L, eigenvectors=True)
        sorted, indices = torch.sort(e, descending=False)
        return v[:,indices[:num]]

    def run(self):

        acclist = []
        nmilist = []
        losslist = []
        loss1list = []
        loss2list = []
        dim = [[] for i in range(len(self.data))]
        torch.cuda.empty_cache()
        print(self.parameters())
        optimizer = torch.optim.Adam(self.parameters(), lr=self.learning_rate)
        self.to(self.device)

        self.new_distance_Begin = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        HH = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.H = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.num_clusters])
        HH1 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_font = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_with = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        for g in range(len(self.set)):
            HH1[g,:,:] ,j= self.PCA_fenjie(self.data[self.set[g]])
            dim[g].append(j)
        for k in range(HH1.shape[1]):
            u, s, v = torch.svd(fft.fft(HH1[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

            s_xin1 = torch.ge(s - self.quanzhong *self.W, 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] -  self.quanzhong *self.W[i]
            self.new_distance_font[:, k, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

        for k1 in range(HH1.shape[0]):
            u, s, v = torch.svd(fft.fft(HH1[k1, :, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

            s_xin1 = torch.ge(s - torch.ones([HH1.shape[1], ]), 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] - 1
            self.new_distance_with[k1, :, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

        for y1 in range(len(self.set)):
            AA1 = self.lam1(self.new_distance_font[y1, :, :].cuda().detach()*self.lamb1 + self.new_distance_with[y1, :,:].cuda().detach()*(1-self.lamb1))
            self.H[y1, :, :] = self.Lapacian(AA1.cuda(),self.num_clusters)
            HH[y1, :, :] = self.lam1(self.dianji(self.H[y1, :, :].cuda())+ torch.eye(self.new_distance_font[g, :, :].shape[0]).cuda())
            AA = self.dianji(self.H[y1, :, :].cuda())+ torch.eye(self.new_distance_font[g, :, :].shape[0]).cuda()
            DD = torch.diag_embed(1 / AA.sum(dim=1).sqrt())
            HH1[y1, :, :] = (DD.matmul(AA)).matmul(DD)
            self.new_distance_Begin[y1, :, :] = self.dianji(self.H[y1, :, :].cuda())

        for lam1 in self.lam:

            print("----lam={}----".format(lam1))
            for i in range(self.max_iter):
                print(i)
                optimizer.zero_grad()
                self(HH1)
                loss, loss1,loss2= self.build_loss(HH, lam1, HH1)#,loss3
                loss.backward()
                optimizer.step()

                print(loss, loss1,loss2)#,loss3
                losslist.append(loss.item())
                loss1list.append(loss1.item())
                loss2list.append(loss2.item())
            #self.new_distance_Begin = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

            for e in range(self.new_distance.shape[0]):
                self.new_distance[e, :, :], j= self.PCA_fenjie(self.diwei1[self.set[e]].detach().cuda())
                dim[e].append(j)
                self.new_distance_Begin[e,:,:] = self.new_distance[e,:,:].cuda()*self.lamb1s + self.new_distance_Begin[e,:,:].cuda()*(1-self.lamb1s)

            for k in range(self.new_distance.shape[1]):
                u, s, v = torch.svd(fft.fft(self.new_distance_Begin[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                s_xin1 = torch.ge(s - self.quanzhong * self.W, 0)
                for i in range(s_xin1.shape[0]):
                    if s_xin1[i] == False:
                        s[i] = 0
                    else:
                        s[i] = s[i] - self.quanzhong *self.W[i]
                self.new_distance_font[:, k, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

            for k1 in range(self.new_distance.shape[0]):
                u, s, v = torch.svd(fft.fft(self.new_distance_Begin[k1, :, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                s_xin1 = torch.ge(s -torch.ones([self.new_distance.shape[1], ]), 0)
                for i in range(s_xin1.shape[0]):
                    if s_xin1[i] == False:
                        s[i] = 0
                    else:
                        s[i] = s[i] - 1
                self.new_distance_with[k1, :, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

            for y1 in range(len(self.set)):
                self.new_distance[y1, :, :] = self.new_distance_font[y1, :, :].cuda().detach()*self.lamb1+ self.new_distance_with[y1, :,:].cuda().detach()*(1-self.lamb1)
            for g in range(len(self.set)):
                self.H[g, :, :] = self.Lapacian(( self.lam1(self.new_distance[g, :, :].cuda().detach())), self.num_clusters)

                self.new_distance[g, :, :] = self.dianji(self.H[g, :, :].cuda())
                AA = self.new_distance[g, :, :].cuda().detach() + torch.eye(self.new_distance_font[g, :, :].shape[0]).cuda()
                DD = torch.diag_embed(1 / AA.sum(dim=1).sqrt())
                HH1[g, :, :] = (DD.matmul(AA)).matmul(DD)
                HH[g, :, :] = self.lam1(AA.cuda())

                self.new_distance_Begin[g, :, :] = self.dianji(self.H[g, :, :].cuda())

            self.Consistent()
            acc, nmi = self.clustering(SC=True)
            acclist.append(acc)
            nmilist.append(nmi)

            colors = list(mcolors.CSS4_COLORS.keys())
            # acc_max_id = acclist.index(max(acclist))
            prediction_max = self.prediction  # self.predictionlist[acc_max_id]

            print(evaluation.clustering(prediction_max.astype(np.int32), self.labels))
            predictiondata_max = self.indicator  # self.predictiondata[acc_max_id]

            tsne = TSNE(n_components=2, random_state=0)  # 将文件将为二维
            result = tsne.fit_transform(predictiondata_max)  # [xin_index,:]
            #print(result.shape)
            listdata = [t for t in range(np.unique(self.labels).shape[0])]

            font1 = {'family': 'Times New Roman',
                     'weight': 'normal',
                     'size': 16,
                     }

            # for i in listdata:
            #     plt.scatter(result[self.labels == i+1, 0], result[self.labels == i+1, 1],s=6,c=colors[int(i+1) + 10])  # ,label = "%d"%i
            plt.scatter(result[:, 0], result[:, 1], s=6, c=self.labels, cmap='tab20')
            # plt.scatter(result[pred_index==0, 0], result[pred_index==0, 1], s=6, c=colors[self.num_clusters+15],label = "error")
            plt.xlabel("x", fontsize=16)
            plt.ylabel("y", fontsize=16)
            plt.xticks(fontsize=16)
            plt.yticks(fontsize=16)

            plt.title("The t-SNE visualization of MSRC dataset", fontsize=16)

            plt.show()

        return acclist, nmilist , losslist,loss1list,loss2list,dim

    def Yy_PCA(self, Yy):
        Y = {}

        for g in range(len(self.set)):
            s_sum = 0
            s_sum1 = 0
            YY = torch.matmul(Yy[self.set[g]].cuda().t(), Yy[self.set[g]].cuda())
            e, v = torch.symeig(YY, eigenvectors=True)
            s, indices = torch.sort(e, descending=True)
            for t in range(len(s)):
                s_sum = s_sum + s[t]
            for d in range(len(s)):
                s_sum1 = s_sum1 + s[d]
                print(d)
                if (s_sum1 / s_sum) > self.threshold:
                    #print("jie")
                    Y[self.set[g]] = Yy[self.set[g]].matmul(v[:, indices[:d+1]])
                    break
            print("xin")
            print(d)
        return Y
    def clustering(self, SC=True):
        n_clusters = np.unique(self.labels).shape[0]
        if SC:
            degree = torch.sum(self.S, dim=1).pow(-0.5)
            L = (self.S * degree).t() * degree
            L = L.cpu()
            _, vectors = torch.linalg.eigh(L)
            indicator = vectors[:, -n_clusters:]
            indicator = indicator / (indicator.norm(dim=1) + 10 ** -10).repeat(n_clusters, 1).t()
            self.indicator = indicator.detach().numpy()
            km = KMeans(n_clusters=n_clusters).fit(self.indicator)
            self.prediction = km.predict(self.indicator)

            # print(self.labels.shape, prediction.shape)
            acc, nmi = cal_clustering_metric(self.labels, self.prediction)
            print('SC --- ACC: %5.4f, NMI: %5.4f' % (acc, nmi), end='')
        print('')
        return acc, nmi





"""class Deep_Network(torch.nn.Module):
    def __init__(self, set, data, labels, layers=None,lam = None, num_neighbors=3, learning_rate=10 ** -3,
                 max_iter=50, max_epoch = None, update=True, num_clusteres=3, links=0, device=None,threshold=None):
        super(Deep_Network, self).__init__()
        if layers is None:
            layers = [1024, 256, 64]
        if device is None:
            device = torch.device('cuda: 0' if torch.cuda.is_available() else 'cpu')
        self.set = set
        self.data = data
        self.labels = labels
        self.threshold=threshold
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.num_clusteres = num_clusteres
        self.max_epoch = max_epoch
        self.num_neighbors = num_neighbors + 1
        self.embedding_dim = {}  # layers[-1]
        self.mid_dim = {}  # layers[1]
        self.input_dim = {}  # layers[0]
        for t in self.set:
            self.embedding_dim[t] = layers[t][-1]
            self.mid_dim[t] = layers[t][1]
            self.input_dim[t] = layers[t][0]
        self.update = update
        self.lam = lam
        self.max_neighbors = self.cal_max_neighbors()
        self.links = links
        self.device = device
        self.iter_id = 0
        self.embedding = None
        self._build_up()
        self.dimension = 5
        self.shuzhi = 0

    def creatnet(self,in_dim,out_dim,n):
        linear = torch.nn.Linear(out_dim,in_dim)
        linear.weight = torch.nn.Parameter(torch.rand(out_dim,in_dim))
        linear.bias = torch.nn.Parameter(torch.rand(n,out_dim))
        return linear
    def createw(self):
        weight = torch.zeros([len(self.set),self.num_clusteres, self.num_clusters])
        bias = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.num_clusters])
        for t in range(len(self.set)):
            weight[t,:,:] = torch.rand(self.num_clusteres, self.num_clusters)
            bias[t,:,:] = torch.rand(self.data[self.set[t]].shape[0], self.num_clusters)
        return torch.nn.Parameter(weight, requires_grad=True),torch.nn.Parameter(bias, requires_grad=True)

    def _build_up(self):
        self.weight ,self.bias = self.createw()
        self.linear1 = self.creatnet(self.data[self.set[0]].shape[1], self.mid_dim[self.set[0]],self.data[self.set[0]].shape[0])
        self.relu1 = torch.nn.ReLU(inplace=True)
        self.linear7 = self.creatnet(self.mid_dim[self.set[0]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig1 = torch.nn.Softmax(dim=1)
        self.linearW7 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

        self.linear2 = self.creatnet(self.data[self.set[1]].shape[1], self.mid_dim[self.set[1]],self.data[self.set[0]].shape[0])
        self.relu2 = torch.nn.ReLU(inplace=True)
        self.linear8 = self.creatnet(self.mid_dim[self.set[1]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig2 = torch.nn.Softmax(dim=1)
        self.linearW8 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

        self.linear3 = self.creatnet(self.data[self.set[2]].shape[1], self.mid_dim[self.set[2]],self.data[self.set[0]].shape[0])
        self.relu3 = torch.nn.ReLU(inplace=True)
        self.linear9 = self.creatnet(self.mid_dim[self.set[2]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig3 = torch.nn.Softmax(dim=1)
        self.linearW9 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

        self.linear4 = self.creatnet(self.data[self.set[3]].shape[1], self.mid_dim[self.set[3]],self.data[self.set[0]].shape[0])
        self.relu4 = torch.nn.ReLU(inplace=True)
        self.linear10 = self.creatnet(self.mid_dim[self.set[3]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig4 = torch.nn.Softmax(dim=1)
        self.linearW10 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

        self.linear5 = self.creatnet(self.data[self.set[4]].shape[1], self.mid_dim[self.set[4]],self.data[self.set[0]].shape[0])
        self.relu5 = torch.nn.ReLU(inplace=True)
        self.linear11 = self.creatnet(self.mid_dim[self.set[4]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig5 = torch.nn.Softmax(dim=1)
        self.linearW11 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

        self.linear6 = self.creatnet(self.data[self.set[5]].shape[1], self.mid_dim[self.set[5]],self.data[self.set[0]].shape[0])
        self.relu6 = torch.nn.ReLU(inplace=True)
        self.linear12 = self.creatnet(self.mid_dim[self.set[5]], self.num_clusteres,self.data[self.set[0]].shape[0])
        self.sig6 = torch.nn.Softmax(dim=1)
        self.linearW12 = self.creatnet(self.num_clusteres, self.num_clusters, self.data[self.set[0]].shape[0])

    def cal_max_neighbors(self):
        if not self.update:
            return 0

        size = self.data[self.set[0]].shape[0]
        self.num_clusters = np.unique(self.labels).shape[0]

        return 1.0 * size / self.num_clusters

    def forward(self):
        self.diwei1 = {}
        self.diwei = {}
        h1 = self.linear1(self.data[self.set[0]])
        h2 = self.relu1(h1)
        self.diwei[self.set[0]] = self.linear7(h2)
        #self.diwei[self.set[0]].matmul()
        #self.diwei1[self.set[0]] = self.sig1(h3)

        h4 = self.linear2(self.data[self.set[1]])
        h5 = self.relu2(h4)
        self.diwei[self.set[1]] = self.linear8(h5)
        #self.diwei1[self.set[1]] = self.sig2(h6)

        h7 = self.linear3(self.data[self.set[2]])
        h8 = self.relu3(h7)
        self.diwei[self.set[2]]= self.linear9(h8)
        #self.diwei1[self.set[2]] = self.sig3(h9)

        h11 = self.linear4(self.data[self.set[3]])
        h12 = self.relu4(h11)
        self.diwei[self.set[3]]= self.linear10(h12)
        #self.diwei1[self.set[3]] = self.sig4(h13)

        h14 = self.linear5(self.data[self.set[4]])
        h15 = self.relu5(h14)
        self.diwei[self.set[4]]= self.linear11(h15)
        #self.diwei1[self.set[4]] = self.sig5(h16)

        h17 = self.linear6(self.data[self.set[5]])
        h18 = self.relu6(h17)
        self.diwei[self.set[5]]= self.linear12(h18)
        #self.diwei1[self.set[5]] = self.sig6(h19)

    # 进行更改图
    def update_graph(self):
        weights = adagae1.utils6.cal_weights_via_CAN_updata(self.S, self.num_neighbors, self.num_clusteres)
        weights = weights.detach()
        # raw_weights[h] = raw_weights[h].detach()

        # Laplacian = adagae1.utils6.get_Laplacian_from_weights(weights)
        return weights

    def max_perform(self, perform_list):
        max_acc = []
        for j in range(len(perform_list)):
            max_acc.append(perform_list[j]['result']['accuracy'])
        acc_max_id = max_acc.index(max(max_acc))
        print("最终结果{}".format(perform_list[acc_max_id]['result']))


    def build_loss(self, HH, lam1,HH1):  # , weights
        size = self.num_clusters
        loss = 0
        loss1 = 0
        loss2 = 0
        loss3 = 0
        self.v = {}
        self.zonghe = 0
        self.indices = {}
        self.fenshu = {}



        self.yusuan = {}

        for r in range(len(self.set)):
            self.diwei1[self.set[r]] = HH1[r].cuda().matmul(self.diwei[self.set[r]].cuda())
            loss1 += lam1 * (self.diwei1[self.set[r]].cuda().t().matmul(HH[r].cuda().matmul(self.diwei1[self.set[r]].cuda()))).sum() / self.diwei1[self.set[r]].shape[1] # self.embedding
        loss = loss + loss1
        self.new_distance = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        # 求相似矩阵
        self.yuanwai = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.yuannei = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.Z = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        self.H_H = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.num_clusters])
        for d in range(len(self.set)):

            self.new_distance[d, :, :] = self.dianji(self.diwei1[self.set[d]])  # +torch.ge(distance[d, :, :].cuda(), Pingju.cuda())
            DW = self.jianju(self.diwei1[self.set[d]].cuda())
            H_H = self.jianju(self.H[d,:,:].cuda())


        loss = loss + loss2 #+loss3
        self.weights_xin = torch.zeros([len(self.set) * (len(self.set) - 1), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.weights = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])


        return loss,loss1,loss2#,loss3

    def Consistent(self):
        self.Ada_weights_z = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        self.z_xin = torch.zeros([self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]]).cuda()
        for y in range(len(self.set)):
            self.z_xin += torch.exp(self.new_distance[y, :, :].cuda())

        self.Ada_weights = {}
        for z in range(len(self.set)):
            self.Ada_weights[z] = torch.div(torch.exp(self.new_distance[z, :, :].cuda()), self.z_xin.cuda())

        # self.S得到最终的共识图
        self.Ada_weights_xin = torch.zeros((self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0])).cuda()
        for n in range(len(self.set)):
            self.Ada_weights_xin += self.Ada_weights[n]
            self.Ada_weights_z += torch.mul(self.Ada_weights[n], self.new_distance[n, :, :].cuda())
        self.S = torch.div(self.Ada_weights_z, self.Ada_weights_xin)

    def dianji(self,diwei_feature):
        sigmoid = torch.nn.Sigmoid()
        return sigmoid(diwei_feature.matmul(diwei_feature.t()))

    def jianju(self,diwei_feature):
        softmax = torch.nn.Softmax()
        return softmax(-adagae1.utils6.distance(diwei_feature.t(),diwei_feature.t()))

    def lam1(self,AA):
        #AA = adagae1.utils6.distance(Yy.cuda().detach().t(), Yy.cuda().detach().t())
        DD = torch.diag_embed(AA.sum(dim=1))
        DD1 = torch.diag_embed(1/AA.sum(dim=1).sqrt())
        lam = (DD1.matmul(torch.subtract(DD,AA))).matmul(DD1)
        return lam

    def Lapacian(self,L,num):
        e, v = torch.symeig(L, eigenvectors=True)
        sorted, indices = torch.sort(e, descending=False)
        return v[:,indices[:num]]

    def run(self):


        torch.cuda.empty_cache()
        print(self.parameters())
        optimizer = torch.optim.Adam(self.parameters(), lr=self.learning_rate)
        self.to(self.device)

        self.new_distance_Begin = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        HH = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.H = torch.zeros([len(self.set),self.data[self.set[0]].shape[0], self.num_clusters])
        HH1 = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_font = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])
        self.new_distance_with = torch.zeros([len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])

        for g in range(len(self.set)):
            HH1[g,:,:] = self.dianji(self.data[self.set[g]])
        for k in range(HH1.shape[1]):
            u, s, v = torch.svd(
                    fft.fft(HH1[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

            s_xin1 = torch.ge(s - torch.ones([len(self.set), ]), 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] - 1
            self.new_distance_font[:, k, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

        for k1 in range(HH1.shape[0]):
            u, s, v = torch.svd(
                    fft.fft(HH1[k1, :, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

            s_xin1 = torch.ge(s - torch.ones([HH1.shape[1], ]), 0)
            for i in range(s_xin1.shape[0]):
                if s_xin1[i] == False:
                    s[i] = 0
                else:
                    s[i] = s[i] - 1
            self.new_distance_with[k1, :, :] = fft.ifft(
                    u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

        for y1 in range(len(self.set)):
            AA = self.new_distance_font[y1, :, :].cuda().detach()*0.5 + self.new_distance_with[y1, :,:].cuda().detach()*0.5 + torch.eye(self.new_distance_font[y1, :, :].shape[0]).cuda()
            DD = torch.diag_embed(1/AA.sum(dim=1).sqrt())
            HH1[y1,:,:] = (DD.matmul(AA)).matmul(DD)

            HH[y1,:,:] = self.lam1(self.new_distance_font[y1, :, :].cuda().detach()*0.5 + self.new_distance_with[y1, :,:].cuda().detach()*0.5)
            self.H[y1,:,:] = self.Lapacian(HH[y1,:,:].cuda(), self.num_clusters)
            self.new_distance_Begin[y1,:,:] = self.dianji(self.H[y1,:,:])

        for lam1 in self.lam:

            print("----lam={}----".format(lam1))
            for i in range(self.max_iter):
                print(i)
                optimizer.zero_grad()
                self()
                loss, loss1,loss2= self.build_loss(HH, lam1,HH1)#,loss3
                loss.backward()
                optimizer.step()

                print(loss, loss1,loss2)#,loss3

            self.new_distance_Begin = torch.zeros(
                [len(self.set), self.data[self.set[0]].shape[0], self.data[self.set[0]].shape[0]])




            for k in range(self.new_distance.shape[1]):
                u, s, v = torch.svd(fft.fft(self.new_distance[:, k, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                s_xin1 = torch.ge(s - torch.ones([len(self.set), ]), 0)
                for i in range(s_xin1.shape[0]):
                    if s_xin1[i] == False:
                        s[i] = 0
                    else:
                        s[i] = s[i] - 1
                self.new_distance_font[:, k, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

            for k1 in range(self.new_distance.shape[0]):
                u, s, v = torch.svd(fft.fft(self.new_distance[k1, :, :].cpu().detach()))  # torch.subtract(ZZ[:,:,j],(1/p)*Y2[i,:,:])

                s_xin1 = torch.ge(s - torch.ones([self.new_distance.shape[1], ]), 0)
                for i in range(s_xin1.shape[0]):
                    if s_xin1[i] == False:
                        s[i] = 0
                    else:
                        s[i] = s[i] - 1
                self.new_distance_with[k1, :, :] = fft.ifft(u.matmul(torch.complex(torch.Tensor(torch.diag(s)), torch.zeros([s.shape[0], s.shape[0]]))).matmul(
                        v.t()))

            for y1 in range(len(self.set)):
                self.new_distance[y1, :, :] = self.new_distance_font[y1, :, :].cuda().detach()*0.5 + self.new_distance_with[y1, :,:].cuda().detach()*0.5

            for g in range(len(self.set)):
                AA = self.new_distance[g, :, :].cuda().detach() + torch.eye(self.new_distance_font[g, :, :].shape[0]).cuda()
                DD = torch.diag_embed(1 / AA.sum(dim=1).sqrt())
                HH1[g, :, :] = (DD.matmul(AA)).matmul(DD)

                self.H[g, :, :] = self.Lapacian((HH[g, :, :].cuda()+self.lam1(self.new_distance[g, :, :].cuda().detach()))/2, self.num_clusters)
                HH[g, :, :] = self.lam1(self.new_distance[g, :, :].cuda().detach())
                self.new_distance_Begin[g, :, :] = self.dianji(self.H[g, :, :].cuda())

            self.Consistent()
            acc, nmi = self.clustering(SC=True)

            colors = list(mcolors.CSS4_COLORS.keys())
            # acc_max_id = acclist.index(max(acclist))
            prediction_max = self.prediction  # self.predictionlist[acc_max_id]
            print(AMLG.evaluation.clustering(prediction_max.astype(np.int), self.labels))
            predictiondata_max = self.indicator  # self.predictiondata[acc_max_id]

            tsne = TSNE(n_components=2, random_state=0)  # 将文件将为二维
            result = tsne.fit_transform(predictiondata_max)  # [xin_index,:]
            listdata = [t for t in range(np.unique(self.labels).shape[0])]
            font1 = {'family': 'Times New Roman',
                     'weight': 'normal',
                     'size': 16,
                     }
            for i in listdata:
                plt.scatter(result[np.sort(prediction_max) == i, 0], result[np.sort(prediction_max) == i, 1],
                            s=6,
                            c=colors[int(i) + 10])  # ,label = "%d"%i
            # plt.scatter(result[pred_index==0, 0], result[pred_index==0, 1], s=6, c=colors[self.num_clusters+15],label = "error")
            plt.xlabel("x", fontsize=16)
            plt.ylabel("y", fontsize=16)
            plt.xticks(fontsize=16)
            plt.yticks(fontsize=16)

            plt.title("The t-SNE visualization of MSRC-v1 dataset", fontsize=16)

            plt.show()

        self.Consistent()
        acc, nmi = self.clustering(SC=True)

        colors = list(mcolors.CSS4_COLORS.keys())
        # acc_max_id = acclist.index(max(acclist))
        prediction_max = self.prediction  # self.predictionlist[acc_max_id]
        print(AMLG.evaluation.clustering(prediction_max.astype(np.int), self.labels))
        predictiondata_max = self.indicator  # self.predictiondata[acc_max_id]

        tsne = TSNE(n_components=2, random_state=0)  # 将文件将为二维
        result = tsne.fit_transform(predictiondata_max)  # [xin_index,:]
        listdata = [t for t in range(np.unique(self.labels).shape[0])]
        font1 = {'family': 'Times New Roman',
                 'weight': 'normal',
                 'size': 16,
                 }
        for i in listdata:
            plt.scatter(result[np.sort(prediction_max) == i, 0], result[np.sort(prediction_max) == i, 1], s=6,
                        c=colors[int(i) + 10])  # ,label = "%d"%i
        # plt.scatter(result[pred_index==0, 0], result[pred_index==0, 1], s=6, c=colors[self.num_clusters+15],label = "error")
        plt.xlabel("x", fontsize=16)
        plt.ylabel("y", fontsize=16)
        plt.xticks(fontsize=16)
        plt.yticks(fontsize=16)

        plt.title("The t-SNE visualization of MSRC-v1 dataset", fontsize=16)

        plt.show()


        return acc, nmi, AMLG.evaluation.clustering(prediction_max.astype(np.int), self.labels)
    def Yy_PCA(self, Yy):
        Y = {}
        for g in range(len(self.set)):
            s_sum = 0
            s_sum1 = 0
            YY = torch.matmul(Yy[self.set[g]].cuda().t(), Yy[self.set[g]].cuda())
            e, v = torch.symeig(YY, eigenvectors=True)
            s, indices = torch.sort(e, descending=True)
            for t in range(len(s)):
                s_sum = s_sum + s[t]
            for d in range(len(s)):
                s_sum1 = s_sum1 + s[d]
                if (s_sum1 / s_sum) > self.threshold:
                    #print("jie")
                    Y[self.set[g]] = Yy[self.set[g]].matmul(v[:, indices[:d+1]])
                    break

        return Y
    def clustering(self, SC=True):
        n_clusters = np.unique(self.labels).shape[0]
        if SC:
            degree = torch.sum(self.S, dim=1).pow(-0.5)
            L = (self.S * degree).t() * degree
            L = L.cpu()
            _, vectors = L.symeig(True)
            indicator = vectors[:, -n_clusters:]
            indicator = indicator / (indicator.norm(dim=1) + 10 ** -10).repeat(n_clusters, 1).t()
            self.indicator = indicator.detach().numpy()
            km = KMeans(n_clusters=n_clusters).fit(self.indicator)
            self.prediction = km.predict(self.indicator)

            # print(self.labels.shape, prediction.shape)
            acc, nmi = cal_clustering_metric(self.labels, self.prediction)
            print('SC --- ACC: %5.4f, NMI: %5.4f' % (acc, nmi), end='')
        print('')
        return acc, nmi"""



