from model85_xin import Deep_Network#1369
import torch
import data_loader6 as loader
from sklearn.preprocessing import normalize
import warnings
import numpy as np
import matplotlib.pyplot as plt
import time
warnings.filterwarnings('ignore')
import random

#
dataset_name = 'caltech'
data, labels = None, None
if dataset_name == 'scene':
    dataset = ["0", "1", "2"]  # ,"3","4","5"
    path = loader.scene
    lamb = [0.7,0.8,0.9]#font+witch
    lambs = [0.7,0.8,0.9]#HH+PCA0.30.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9
    thresholds = [0.9]
    W = [1, 1]
    clusters = [10]

if dataset_name == 'caltech':
    dataset = ["0", "1", "2", "3", "4"]
    path = loader.caltech
    lamb = [0.5]
    lambs = [0.5]
    thresholds = [0.7]
    W = [0.1,1,1,10,1]
    clusters = [64]


elif dataset_name == 'bbc':
    dataset = ["0", "1"]
    path = loader.bbc
    lamb = [0.6]
    lambs = [0.1]
    thresholds = [0.9]
    W = [1, 1]

elif dataset_name == 'webkb':
    dataset = ["0", "1"]
    path = loader.webkb
    lamb = [0.7]
    lambs = [0.9]
    thresholds = [0.9]
    W = [0.1, 1]

elif dataset_name == 'sources':
    dataset = ["0", "1", "2"]
    path = loader.sources
elif dataset_name == 'orl':
    dataset = ["0", "1", "2"]
    path = loader.orl
    lamb = [0.5]
    lambs = [0.5]
    thresholds = [0.7]
    W = [1, 100, 50]


elif dataset_name == 'caltech':
    dataset = ["0", "1", "2", "3", "4", "5"]
    path = loader.caltech
elif dataset_name == 'leaves':
    dataset = ["0", "1", "2"]
    path = loader.leaves
elif dataset_name == 'msrcv':
    dataset = ["0", "1", "2", "3", "4", "5"]
    path = loader.msrcv
    lamb = [0.5]
    lambs = [0.5]
    thresholds = [0.5]
    W = [0.1, 0.1, 0.1, 0.1, 0.1, 0.1]
    clusters = [64]

elif dataset_name == 'coil20':
    dataset = ["0", "1", "2"]  # ,"3","4","5"
    path = loader.COIL20X  # "
    lamb = [0.5]
    lambs = [0.3]
    thresholds = [0.8]
    W = [0.1, 10, 100]
    clusters = [64]

elif dataset_name == 'mfeat':
    dataset = ["0", "1", "2", "3", "4", "5"]
    path = 'mfeat'
    lamb = [0.5]
    lambs = [0.5]
    thresholds = [0.5]
    W = [0.1, 1, 1, 1, 10, 10]  
    clusters = [10]

if data is None or labels is None:
    [data, labels] = loader.load_data(path)


lam = np.power(2.0, np.array(range(-10, 10, 2)))
# lam = [0.5]




#300
"""dataset = ["0","1","2","3","4","5"]
path = loader.msrcv
[data, labels] = loader.load_data(path)"""

"""dataset = ["0", "1", "2"]  # ,"3","4","5"
path = loader.COIL20X  # "MSRCV1""ORL_mtv"'COIL20-3v''COIL20-3v'"YaleA_3view"1"bbcsport","Caltech101-7"
[data, labels] = loader.load_data(path)"""

"""dataset = ["mfeat-fac","mfeat-fou","mfeat-kar","mfeat-mor","mfeat-pix","mfeat-zer"]#["mfeat-fac","mfeat-fou","mfeat-kar","mfeat-mor","mfeat-pix","mfeat-zer"]
[data, labels] = loader.load_data(dataset)"""

"""dataset = ["0", "1", "2"]  # ,"3","4","5"
path = loader.scene  # "MSRCV1""ORL_mtv"'COIL20-3v''COIL20-3v'"YaleA_3view"1"bbcsport","Caltech101-7"
[data, labels] = loader.load_data(path)"""

"""dataset = ["0","1","2"]
path = loader.leaves
[data, labels] = loader.load_data(path)"""
"""dataset = ["0", "1"]  # ,"3","4","5"
path = loader.bbc  # "MSRCV1""ORL_mtv"'COIL20-3v''COIL20-3v'"YaleA_3view"1"bbcsport","Caltech101-7"
[data, labels] = loader.load_data(path)"""
"""dataset = ["0", "1"]  # , "2","3","4","5"
path = loader.webkb  # "MSRCV1""ORL_mtv"'COIL20-3v''COIL20-3v'"YaleA_3view"1"bbcsport","Caltech101-7"
[data, labels] = loader.load_data(path)"""
"""dataset = ["0", "1", "2"]  # ,"3","4","5"
path = loader.sources  # "MSRCV1""ORL_mtv"'COIL20-3v''COIL20-3v'"YaleA_3view"1"bbcsport","Caltech101-7"
[data, labels] = loader.load_data(path)"""
"""dataset = ["0", "1", "2"]  # ,"3","4","5"
path = loader.orl  # "MSRCV1""ORL_mtv"'COIL20-3v''COIL20-3v'"YaleA_3view"1"bbcsport","Caltech101-7"
[data, labels] = loader.load_data(path)"""
"""dataset = ["0", "1", "2","3","4","5"]  #
path = loader.caltech  # "MSRCV1""ORL_mtv"'COIL20-3v''COIL20-3v'"YaleA_3view"1"bbcsport","Caltech101-7"
[data, labels] = loader.load_data(path)"""
'''print(data1.shape)
[data, labels] = loader.load_guanpudata()'''



device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
input_dim = {}
for e in dataset:
    data[e] = torch.Tensor(data[e].astype(float)).to(device)#.t()
    print(data[e].shape)
#X = torch.Tensor(data).to(device)
    input_dim[e] = data[e].shape[0]
layers = {}
"""if dataset is loader.USPS:
    layers = [input_dim, 128, 64]

else:"""
"""(2000, 216)
(2000, 76)
(2000, 64)
(2000, 6)
(2000, 240)
(2000, 47)"""
for h in dataset:
    layers[h] = [input_dim[h], 128, 16]
"""layers[dataset[0]] = [input_dim[dataset[0]], 64, 32]
layers[dataset[1]] = [input_dim[dataset[1]], 64, 32]
layers[dataset[2]] = [input_dim[dataset[2]], 64, 32]
layers[dataset[3]] = [input_dim[dataset[3]], 6, 4]
layers[dataset[4]] = [input_dim[dataset[4]], 64, 32]
layers[dataset[5]] = [input_dim[dataset[5]], 32, 16]"""
#0.9048	0.8154	0.8062	0.9102	0.9048	0.9044	0.7914

"""accs = [];
nmis = [];
cishu=[7,9,11,13,15,17,19]#,12,14,16,18,20,22,24,26,28,30,32,34,36]6,7,8,9,10,11,12,13,14,15,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48
rate_jihe = [0.05]#0.07,0.002,0.07,0.1,0.07,0.02,0.01,0.07,0.05,0.07,
chaju_jihe = [4]#110,120,130,140,150,2,4,6,8,10,12,14,16,18,12,6,2,4,6,8,10,12，16,18,,14,20,,14
for num_cluster in cishu:
    for rate in rate_jihe:
        for cha in chaju_jihe:
            for neighbors in [5]:
                random.seed(1)
                start = time.time()
                print('-----cishu={},neighbors={},Rate={},cha={}'.format(num_cluster, neighbors, rate, cha))
                gae = Deep_Network(dataset, data, labels, layers=layers, num_neighbors=neighbors,max_iter=cha,
                             update=True, learning_rate=rate, num_clusteres=num_cluster, device=device)
                acc, nmi, best_perform = gae.run()
                end = time.time()
                print("循环运行时间:%.2f秒" % (end - start))
            accs.append(acc)
            nmis.append(nmi)
            print(acc, nmi, best_perform )
plt.figure()

ax = plt.axes()
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

plt.xlabel('Dimensions',fontsize=16)  # x轴标签
plt.ylabel('Clustering performance',fontsize=16)  # y轴标签
plt.ylim(0,1.00)
plt.yticks(np.arange(0,1.05,0.10),fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
# 以x_train_loss为横坐标，y_train_loss为纵坐标，曲线宽度为1，实线，增加标签，训练损失，
# 默认颜色，如果想更改颜色，可以增加参数color='red',这是红色。
plt.plot(cishu, accs, linewidth=2.5, linestyle="solid", marker='^',label="acc")
plt.plot(cishu, nmis, linewidth=2.5, linestyle="solid",marker='*', label="nmi")
plt.grid(linestyle="-.", axis='y', alpha=0.4)
plt.legend()
plt.title('COIL-20 database',fontsize=16)
plt.show()"""
accs = [];
nmis = [];
quanzhong1=[1]  #,12,14,16,18,20,22,24,26,28,30,32,34,36]6,7,8,9,10,11,12,13,14,15,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48
rate = 0.005  #0.07,0.002,0.07,0.1,0.07,0.02,0.01,0.07,0.05,0.07,
Iters = 100   #110,120,130,140,150,2,4,6,8,10,12,14,16,18,12,6,2,4,6,8,10,12，16,18,,14,20,,14



for quanzhong in quanzhong1:
    for threshold in thresholds:
        for lamb1s in lambs:
            for lamb1 in lamb:
                for num_clusters in clusters:

                                random.seed(1)
                                start = time.time()

                                print(
                                    '-----cishu={},Rate={},cha={},W={},clusters={},lamb={},lamb1s={},threshold={}'.format(
                                        lam, rate, Iters, W,
                                        num_clusters,
                                        lamb1, lamb1s, threshold))
                                with open("WebKB.txt", 'a') as f:
                                    f.write(
                                        '-----cishu={},Rate={},cha={},W={},clusters={},lamb={},lamb1s={},threshold={}'.format(
                                            lam, rate, Iters, W,
                                            num_clusters,
                                            lamb1, lamb1s, threshold))

                                    gae = Deep_Network(dataset, data, labels, layers=layers, lam=lam,
                                                       max_iter=Iters,
                                                       max_epoch=30,
                                                       update=True, learning_rate=rate, num_clusteres=num_clusters,
                                                       device=device,
                                                       W=torch.Tensor(W), lamb1=lamb1, lamb1s=lamb1s,
                                                       threshold=threshold, quanzhong=quanzhong).to(device)
                                    acc, nmi, loss, loss1, loss2, dim = gae.run()
                                    end = time.time()
                                    print("循环运行时间:%.2f秒" % (end - start))
                                    f.write("acc={};\nnmi={}\n".format(acc, nmi))
                                    f.close()

                                    plt.figure()

                                    ax = plt.axes()
                                    ax.spines['top'].set_visible(False)
                                    ax.spines['right'].set_visible(False)

                                    plt.xlabel('Iter', fontsize=16)  # x轴标签
                                    plt.ylabel('Dimension', fontsize=16)  # y轴标签
                                    # plt.ylim(0, 1.00)
                                    # plt.yticks(np.arange(0, 1.05, 0.10), fontsize=16)
                                    # lambda2 = [2 ** x for x in range(-10, 10, 2)]
                                    # x_tickets = [str(_x) for _x in lambda2]
                                    # x = list(range(len(lambda2)))

                                    plt.xticks(fontsize=12)
                                    plt.yticks(fontsize=12)
                                    # 以x_train_loss为横坐标，y_train_loss为纵坐标，曲线宽度为1，实线，增加标签，训练损失，

                                    plt.plot(range(len(dim[0])), dim[0], linewidth=2.5, linestyle="solid", marker='^',
                                             label="views1")
                                    plt.plot(range(len(dim[1])), dim[1], linewidth=2.5, linestyle="solid", marker='*',
                                             label="views2")
                                    """plt.plot(range(len(dim[2])),  dim[1], linewidth=2.5, linestyle="solid", marker='*',
                                             label="views3")"""
                                    plt.grid(linestyle="-.", axis='y', alpha=0.4)
                                    plt.legend()
                                    plt.title('bbcsport database', fontsize=16)

                                    """plt.xlabel('Iter', fontsize=16)  # x轴标签
                                    plt.ylabel('Error', fontsize=16)  # y轴标签
                                    # plt.ylim(0, 1.00)
                                    # plt.yticks(np.arange(0, 1.05, 0.10), fontsize=16)
                                    plt.xticks(fontsize=16)
                                    plt.yticks(fontsize=16)
                                    # 以x_train_loss为横坐标，y_train_loss为纵坐标，曲线宽度为1，实线，增加标签，训练损失，
                                    # 默认颜色，如果想更改颜色，可以增加参数color='red',这是红色。


                                    ax.plot(range(len(loss1)), loss1, linewidth=2, linestyle="solid", marker='^',
                                            label="loss1")
                                    ax.plot(range(len(loss2)), loss2, linewidth=2, linestyle="solid", marker='*',
                                            label="loss2")
                                    ax.legend()
                                    ax.grid(linestyle="-.", axis='y', alpha=0.4)

                                    plt.title('bbcsport database', fontsize=16)"""
                                    plt.show()
































